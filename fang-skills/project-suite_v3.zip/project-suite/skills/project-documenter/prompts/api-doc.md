# API Doc Prompt

## 任务

你是 API 文档生成专家。从 TypeScript API 模块代码提取接口文档。

## 前置

1. 读 API 模块源码（`.ts` 文件）
2. 读项目 API 规范（`api/request.md` 若存在）
3. 读 1 份已有 API 文档（若存在）确认风格

## 输入

```
API 模块文件：{{file_path}}
{{#if focus}}
聚焦接口：{{focus}}
{{/if}}
```

## 对每个接口提取

```markdown
### `functionName` — 接口用途

> 从 JSDoc 提取，无则写"从函数名推断"

| 项目 | 值 |
|------|-----|
| **方法** | GET / POST / PUT / DELETE |
| **路径** | `/api/resource` |
| **鉴权** | 需要登录 / 公开 / 需要 XX 权限 |

**请求参数**

| 参数 | 类型 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| pageindex | number | 是 | - | 页码 |
| keyword | string | 否 | '' | 搜索关键词 |

**响应**

```typescript
// 成功 200
{ data: Item[], total: number }

// 错误 400
{ error: string, message: string }
```

**源文件**: `src/api/user.ts:42-58`
```

## 不编造

- JSDoc 没有的功能描述 → 写"无描述，见函数名推断"
- 代码中看不出接口用途 → 标注 `[待补充]`
- 不确定是否必填 → 看代码默认值，无默认值标注必填

## 输出格式

一个 `.md` 文件，严格遵循以上模板。多个接口时按文件从上到下排列。
