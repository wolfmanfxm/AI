# Unified Skill I/O Contract

> 所有 Skill 的输入输出遵循统一格式。Skill 之间通过 State 通信，不直接调用。

## 输入：4 个标准入口

每个 Skill 启动时接收这 4 个输入：

```
┌─────────────────────────────────────────┐
│               Skill Input               │
├───────────────┬─────────────────────────┤
│ task_id       │ 当前任务身份（默认由 Discovery 解析）│
│ context.json  │ 项目技术上下文            │
│ state.json    │ 项目当前状态 + 上游产出    │
│ task.md       │ 当前任务描述              │
│ context-package.json │ 知识注入（预消化，唯一入口，按 task_id 隔离）│
└───────────────┴─────────────────────────┘
```

> 🔴 **task_id 是一等输入**：Discovery 第 0 步解析（[task-identity.md](../mechanisms/task-identity.md)）。
> 未解析出 task_id 时不得读写任何任务级文件。

### context.json（来自 Analyzer）
```json
{
  "techStack": { "framework": "<框架>", "ui": "<组件库>", "lang": "<语言>" },
  "aliases": { "@": "src", "<业务层别名>": "workspace" },
  "conventions": { "component": "<组件范式>", "form": "reactive()" },
  "modules": ["<api 目录>/", "<页面目录>/", "<组件目录>/"]
}
```

### state.json（来自 .project-knowledge/runtime/）
```json
{
  "phase": "generating",
  "current": { "skill": "project-generator", "task_id": "task-20261109-user-approval" },
  "active_tasks": {
    "task-20261109-user-approval": { "skill": "project-generator", "status": "in_progress" }
  },
  "history": [
    {"task_id": "task-20261109-user-approval", "skill": "project-planner", "confidence": 85, "output": "proposals/PLAN-task-20261109-user-approval.md"},
    {"task_id": "task-20261109-user-approval", "skill": "project-architect", "confidence": 90, "output": "decisions/ARCHITECTURE-task-20261109-user-approval.md"}
  ],
  "blockers": []
}
```

### task.md（当前任务）
当前 Skill 需要完成的具体任务描述。来自 PLAN.md 的 Task Breakdown 或用户直接输入。

### context-package.json（知识注入，v2 预消化）

> 知识注入唯一入口 = `runtime/tasks/<task_id>/context-package.json`（Knowledge Resolver 产出，预消化 pattern + constraints + components）。
> Generator 不再读文件、不自己判断——直接遍历 `context.knowledge[]` 注入。见 [knowledge-resolver.md](../knowledge-resolver.md)。

```json
{
  "plan": "PLAN-task-20261109-user-approval.md",
  "taskId": "task-20261109-user-approval",
  "generated_by": "knowledge-resolver",
  "schemaVersion": "2.0.0",
  "context": {
    "knowledge": [
      {"capability": "TablePattern", "pattern": "DataTable + <schema表格>", "constraints": ["<分页参数> 数字"], "anti_pattern": "不要手写 el-table", "source": "patterns/table.md"}
    ],
    "components": [{"name": "Dialog", "path": "@app/components/common/Dialog", "reuse": true}],
    "api": [{"module": "order", "functions": ["getPage"], "conventions": ["export function 风格"]}],
    "rules": [{"rule": "workspace-priority", "constraint": "组件从 @app/components/ 引入", "blocking": true}]
  }
}
```

**规则：**
- Planner 在 `# Reuse Analysis` 中列出可复用资产 → Resolver 产出 `runtime/tasks/<task_id>/context-package.json`
- Generator 启动时读**自己 task_id** 的知识包 → 遍历 `context.knowledge[]` 直接注入，遵守 constraints、避免 anti_pattern
- 消费前校验包内 `taskId` == 当前 task_id；不一致 → 🔴 拒绝消费（不是自己的知识）
- Generator **不搜索** `.project-knowledge/` — 不知道还有别的知识
- Context 恒定、可预测、不膨胀

> ⚠️ **Legacy**：`knowledge-list.json`（v1 文件路径清单，Generator 自行解析）已废弃，被 `context-package.json` 取代。新 Skill 不得再以其为正式输入。见 [knowledge-resolver.md](../knowledge-resolver.md)「Legacy Compatibility」。

## 输出：3 个标准出口

```
┌─────────────────────────────────────────┐
│              Skill Output               │
├───────────────┬─────────────────────────┤
│ 收尾报告       │ 执行结果摘要（名字由 skill 自定，见下）│
│ state.json 更新建议 │ 提交给 Dispatcher，不直接写根 State │
│ 产出文件       │ .project-knowledge/ 子目录 │
└───────────────┴─────────────────────────┘
```

### 收尾报告（统一格式，文件名由 skill 自定）

> 每个 Skill 必须产出**一份**收尾报告（`gates.yaml` `require_closing_report`），遵循下面的统一格式。
> **文件名由 skill 自定**，不存在一个强制叫 `result.md` 的文件——各 skill 的实际报告名：

| Skill | 收尾报告文件名 |
|-------|--------------|
| analyzer | `runtime/tasks/<task_id>/validation-report.md`（+ verification-report.md） |
| planner | `runtime/tasks/<task_id>/validation-report.md` |
| architect | `decisions/ARCHITECTURE-<task_id>.md`（ADR 本身即收尾） |
| generator | `runtime/tasks/<task_id>/completion-report.md` |
| tester | `reports/TEST-REPORT-<task_id>.md` |
| reviewer | `reports/REVIEW-<task_id>[-<topic>].md` |
| refactorer | `reports/REFACTOR-<task_id>.md` |
| documenter | 文档本身（含 Evidence Header） |
| releaser | `reports/CHANGELOG.md` + `reports/RELEASE-CHECKLIST.md`（项目级，单写者） |
| pipeline-orchestrator | `runtime/tasks/<task_id>/pipeline-report.md` |

> 任务级报告一律带 `<task_id>`；项目级产物（analyzer 的 6 个根文件、知识目录）不带。

统一格式（内容结构，非文件名）：

```markdown
# Result: {skill-name}

**Status:** {completed | degraded | blocked}
**Confidence:** {0-100}%
**Summary:** [一句话摘要]

**Convergence:** {sufficient | insufficient | blocked} → {handoff | continue | investigate | blocked}
**Evidence:** [支撑收敛判断的证据]

## What Was Done
- [具体做了什么]

## What Was NOT Done
- [明确未覆盖的内容 + 原因]

## Issues
| # | 类型 | 描述 | 严重度 |
|---|------|------|--------|
| 1 | gap | API 文档缺失，部分端点基于推断 | medium |

## Next
**Suggested:** {下一步 Skill 建议}
**Blockers:** {阻塞后续执行的问题}
```

> **Convergence**（统一停止条件）是 Suite 一级原语：`sufficient`=证据够、停下；`insufficient`=缺证据、补；`blocked`=缺输入、回上游。见 [convergence.md](../../shared/primitives/convergence.md)。

### state.json（只读 + 提交更新建议）

**Skill 不直接写根 `.project-knowledge/runtime/state.json`。** 根 State 是项目级唯一权威，
由 **Dispatcher 串行提交**（同一项目同一时刻一个写者）。Skill 只读它了解当前状态，
并在收尾报告里产出建议：

```json
{
  "state_update_suggestion": {
    "phase": "generating",
    "status": "in_progress",
    "history_entry": {
      "task_id": "task-20261109-user-approval",
      "skill": "project-generator",
      "status": "completed",
      "confidence": 85,
      "output": "src/views/user-approval/",
      "at": "2026-11-09T14:10:00Z"
    },
    "blockers": []
  }
}
```

| 内容 | 写入者 | 位置 |
|------|--------|------|
| 执行进度（phase / 子任务） | 当前 Skill | `.sessions/<task_id>/<skill>/state.json` |
| 运行终态 | `runtime-run.sh finish` | `runtime/metrics/timeline.jsonl` |
| phase / status / active_tasks / history / blockers | **仅 Dispatcher** | `runtime/state.json` |

> 并行任务**不得**直接读改写根 `state.json`：每个 Skill 只产出 State 更新建议，
> 由 Dispatcher 串行提交。见 [task-identity.md](../mechanisms/task-identity.md)。

### timeline.jsonl（执行指标追加）

**每次 Run 的终态由 `runtime-run.sh finish` 追加一行**；`pipeline-orchestrator` 是 Dispatcher 类
Skill，没有自己的 Run，因此不追加（这是唯一例外）。

最简写入（必填字段）：
```json
{
  "taskId": "task-20261109-user-approval",
  "runId": "task-20261109-user-approval/project-xxx/2026-11-09T14:10:00Z",
  "skill": "project-xxx",
  "wave": 4,
  "status": "completed",
  "timing": { "startedAt": "ISO-8601", "finishedAt": "ISO-8601", "durationMs": 125000 },
  "output": { "filesGenerated": 3 },
  "quality": { "confidence": 85 }
}
```

完整写入（建议能填就填）：
```json
{
  "taskId": "task-20261109-user-approval",
  "runId": "task-20261109-user-approval/project-xxx/2026-11-09T14:10:00Z",
  "skill": "project-xxx",
  "wave": 4,
  "status": "completed",
  "timing": { "startedAt": "...", "finishedAt": "...", "durationMs": 125000 },
  "input": {
    "planFile": "...",
    "capabilitiesUsed": ["<框架约定>","TablePattern"],
    "knowledgeFilesRead": 4,
    "contextSizeEstimate": "~45k tokens"
  },
  "output": {
    "filesGenerated": 3,
    "artifacts": ["..."],
    "linesOfCode": 320,
    "approxTokens": 28000
  },
  "quality": {
    "confidence": 85,
    "warnings": 2,
    "errors": 0
  },
  "dependencies": {
    "upstreamSkills": ["project-analyzer","project-planner"],
    "upstreamConfidenceMin": 90
  }
}
```

**写入时机**：timeline 终态由 `runtime-run.sh finish` 在收尾时追加；**所有退出路径**都要走它
（见 workflow-protocol 的 Terminal Record）。Skill 自己产出的是 State 更新建议，不是根 State 写入。
**写入方式**：`bash shared/scripts/runtime-run.sh finish <project-root> --skill <name> --status <status> [--confidence N]`——
它负责追加一行 timeline、释放单写者锁、清理运行指针；**不修改长期 Task 的 status**。不要直接调 `timeline-append.sh`：
`runId` 以 `start` 时的记录为准，分头调用会写出不一致的 runId。
底层仍是 append-only 单次追加，**禁止**读 `timeline.jsonl` → 改 → 写回。

→ 完整协议：[../metrics/timeline.md](../metrics/timeline.md)

### 产出文件
- 任务级：`runtime/tasks/<task_id>/`（session / context-package / pipeline-state / manifest-<skill>.json）+ 命名带 task_id 的 PLAN/ARCHITECTURE/REPORT
- 项目级：`architecture/` `components/` `api/` `patterns/` 等（不带 task_id）

## 各 Skill 的映射

| Skill | Input: task.md 来源 | Output（.project-knowledge/ 子目录） |
|-------|--------------------|--------------------|
| analyzer | 用户需求（分析范围） | 知识文件（patterns/ components/ api/ 等，项目级） |
| planner | 用户需求 | `proposals/PLAN-<task_id>.md` |
| architect | PLAN.md > # Decision | `decisions/ARCHITECTURE-<task_id>.md` |
| generator | PLAN.md > # Task Breakdown | code（项目目录） |
| tester | PLAN.md > # Acceptance Criteria | `reports/TEST-REPORT-<task_id>.md` |
| reviewer | 变更 diff | `reports/REVIEW-<task_id>.md` |
| refactorer | 重构目标描述 | code + `reports/REFACTOR-<task_id>.md` |
| documenter | 文档需求 | 项目内文档（含 Evidence Header） |
| releaser | 发布指令 | `reports/CHANGELOG.md`（项目级，单写者） |

## 置信度（Confidence）

**所有 Skill 输出必须包含 Confidence 评分。**

| Score | 含义 | Gate | 行为 |
|-------|------|------|------|
| 90-100 | 高置信度，产出可靠 | 🟢 PASS | 直接进入下游 |
| 70-89 | 中等置信度，有标注的假设 | 🟡 REVIEW | 建议 Review 后推进 |
| 40-69 | 低置信度，信息不足 | 🟠 GATE | 强制 Review，禁止 Release |
| < 40 | 不可靠 | 🔴 BLOCK | 阻断，必须重做或人工介入 |

Confidence 计算规则（各 Skill 通用框架）：
```
confidence = 100
- 20 if 输入信息模糊/不完整
- 15 if 依赖的 knowledge 状态非 accepted
- 15 if 依赖的上游产出置信度 < 70
- 10 if 遇到未预见的边界条件
- 10 if 使用了降级/fallback 模式
- 5  per 未验证假设（max -20）
```

**Confidence Gate 行为：**
- 🟢 PASS → 下游正常执行，State 更新建议中记录 `gate: "PASS"`
- 🟡 REVIEW → 下游正常执行，建议中标注 `gate: "REVIEW"` + AskUserQuestion
- 🟠 GATE → Reviewer 强制执行后才能进入 Generator；Releaser 拒绝执行
- 🔴 BLOCK → State 更新建议中写入 blocker，下游 Skill 启动时检测到 blocker → 拒绝执行
  （根 `state.json` 由 Dispatcher 提交后才对其他任务可见）

→ 完整 Gate 协议：[../mechanisms/confidence-gate.md](../mechanisms/confidence-gate.md)
