# Delivery — Reviewer

> @template: delivery

## Actions

写入 `.project-knowledge/reports/REVIEW-<task_id>[-<topic>].md`：

1. **问题列表**（按 BLOCKER → HIGH → MEDIUM → LOW 排序）—— 每个 finding 分配 `F-xxx` ID，并标注 `against: AC-xxx`（该 finding 违反哪条 AC，无对应 AC 则标 `against: -`）
2. **PRAISE**（值得学习的代码）
3. **AC 对照表**（每条 AC 的 ✅/❌/⚠️ 状态）
4. **审查结论**（PASS / NEEDS_FIX / BLOCKED）
5. **Validation notes**（元审查结果）
6. **Independent QA**（命中触发条件时）——`Missed` / `Confirmed` / `Rejected` 三节；
   未命中 → 标 `[QA SKIPPED: 未命中触发条件]` 或 `[QA SKIPPED: 原因]`

## Exit

- `REVIEW-<task_id>[-<topic>].md` 写入成功
- 提交 State 更新建议（confidence + history；Dispatcher 统一提交根 state.json）

## Failure

| Condition | Action |
|-----------|--------|
| 写入失败 | 重试一次 → 仍失败标注 `❌ FAILED` |
