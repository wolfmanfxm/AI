# Knowledge Builder

> 从 Accepted Candidates 组装最终 `.project-knowledge/` 产出。

## Actions

1. 收集 Verifier 输出的所有 Accepted Candidates（含 confidence-adjusted）
2. 按知识类型分组（architecture / patterns / conventions / glossary / decisions / risks / antipatterns）
3. **逐组写入**最终 .md 文件——每组 Candidate 必须覆盖，不得跳过
4. 注入 Evidence Score Section（每个 Claim 的溯源）
5. 生成跨文件交叉引用
6. **存量补齐**：为既有文件补上契约要求但缺失的字段 —— 见下「存量补齐（contract backfill）」

## 存量补齐（contract backfill）

**问题**：契约（[knowledge-directories.yaml](../../../shared/schemas/knowledge-directories.yaml)）要求
`rules/` `decisions/` 必须写 `constraint:`，`patterns/` `components/` `api/` 必须写 `statement:`。
但存量知识库是在这条要求之前产出的——实测真实项目 **8/23** 文件缺 `constraint`，导致 Compiler 拒绝生成
`knowledge-index.json`，**整条知识链中断**。

**每次 Knowledge Builder 执行时都要做**（全量与增量都做，不限增量），扫描目标目录、对**缺失**契约字段的文件补齐：

| 缺失字段 | 补齐方式 |
|---------|---------|
| `constraint`（`rules/` `decisions/`） | 从正文派生**一句硬约束**（「必须 / 禁止 …」） |
| `statement`（`patterns/` `components/` `api/`） | 从正文派生**一句可直接注入的摘要** |

### 四条硬规则

1. **只补缺失，绝不覆盖。** 文件已有该字段就原样不动——人工写过的值是权威，重扫不得回退它。
2. **必须标记来源。** 补写时同时写 `constraint_source: derived-from-body`（`statement` 同理）：
   ```yaml
   constraint: "……"
   constraint_source: derived-from-body   # analyzer 从正文派生，未经人工确认；原始产出者见 generatedBy
   ```
   为什么必须：存量文件来自**多个产出者**（实测同一项目里 `generatedBy` 有 `manual` / `project-analyzer` /
   `architect` / 缺失 四种）。`generatedBy` 记录**谁产的文件**，`*_source` 记录**这个值是派生的还是原作就有的**——
   人工据此才知道该找谁确认。

   > **只对「既有文件」补写时标记**。本次分析**新建**的文件不加此标记——它没有「原作者」，字段就是本次产出的，
   > 加标记反而是噪音（实测出现过这种误标）。
3. **派生不出就不写。** 正文里抽不出硬约束或可注入摘要时（如纯背景描述），**不要编**。在交付报告里列出该文件，
   标 `⚠️ 无法派生 <field>`，交人工补。**宁缺勿造**——写一个假约束比缺字段更坏（它会被当权威注入下游）。
4. **交付报告必须列出所有补写。** 被补写的文件 + 补写的值，逐条列给用户复核。**不得静默补写。**

> 这不是「擅自改别人的文件」：`rules/` `decisions/` 的语义归属仍是原作者（`generatedBy` 可查），
> analyzer 补的只是一个**为满足下游契约而缺的机器可读字段**，全程可回溯、可回退。
> 若某文件的 `generatedBy` 是另一个 suite skill，可考虑由该 skill 复审派生值——但**不阻塞补齐**（否则知识链一直断着）。

## Coverage Gate

**全部完成前不可退出。** 逐项验证——**行集合 = 契约声明的知识目录**
（[knowledge-directories.yaml](../../../shared/schemas/knowledge-directories.yaml)，此处只列落点与验证方式，不重述目录语义）：

| 契约目录 | Candidate 来源 | 落点 | 验证方式 |
|---------|---------------|------|---------|
| `architecture/` | directory / framework / architecture / glossary | `architecture/{modules,tech-stack,overview,glossary}.md` | 目录树 + 技术栈表 + 分层边界 + 术语表已写入 |
| `patterns/` | pattern | `patterns/*.md` | 每种模式独立文件（**必需 `statement:`**） |
| `components/` | components | `components/*.md` | 每个组件独立文件（**必需 `statement:`**） |
| `api/` | api-pattern | `api/*.md` | 每个接口独立文件（**必需 `statement:`**） |
| `conventions/` | convention | `conventions/*.md` | 每种规范独立文件 |
| `rules/` | principle | `rules/principles.md` | Always/Never/Prefer/Avoid 已写入（**必需 `constraint:`**——不然 Compiler 拒绝生成 index） |
| `decisions/` | decision | `decisions/*.md` | 决策记录已写入（**必需 `constraint:`**——同上） |
| `recommendations/` | instinct-extractor | `recommendations/*.md` | **一条建议一个文件**；每条含「现状 → 应然建议 + 依据溯源」 |
| `observations/` | risk / antipattern | `observations/{risks,antipatterns}.md` | 风险清单 + 反模式清单已写入 |
| `candidates/` | 全部 Extractor | `candidates/accepted/*.yaml` | 每个 Extractor ≥1 candidate（V1/V2 已判） |
| **骨架** | — | 契约声明的**每一个**目录 | 目录存在且含 `index.md`——**首扫必须建立完整骨架**，不是「有内容才建」 |

**未覆盖的 Candidate → 返回重写对应文件 → 不可 Exit。**
骨架行由 [check-kb-contract.sh](../../../shared/scripts/check-kb-contract.sh) 机械断言（契约目录全在位 + 6 个固定根产物），
它同时是 Delivery 的阻断门禁——**本表与契约之间不得再插入第二份目录清单**。

> ⚠️ **`recommendations/` 必须在本表有对应行**：`skill.yaml` / `SKILL.md` / `instinct-extractor.md`
> 都声明 analyzer 产出 `recommendations/`，Gate 表就必须覆盖它——**声称产出 ≠ 被覆盖检查，
> 未被 Gate 覆盖的产出等于没要求**。本表和骨架行都按契约派生，不再另列。

### frontmatter 契约（与 Coverage Gate 同级，缺失同样**不可 Exit**）

写入每个目标文件时，按 [shared/schemas/knowledge-directories.yaml](../../../shared/schemas/knowledge-directories.yaml) 的 `required_frontmatter` 补齐字段：

| 目标目录 | 必需字段 | 缺失后果 |
|---------|---------|---------|
| `patterns/` `components/` `api/` | `statement:` | 不报错，但 Resolver 静默退化为标题拼接，注入精度下降（实测真实项目 0/12 合规） |
| `decisions/` | `constraint:` | **Compiler 硬校验**——缺即拒绝生成 `knowledge-index.json`，整条知识链中断 |

> 字段写法见 [output-format.md](output-format.md) 的「字段说明」与 `statement` 小节。
> 契约要求「Producer 该写」的字段，其**声明**由 `check-io-connectivity.sh` 不变量 I4 把关（防止「要求了但没告诉产出者」）。

## Output Structure

**Knowledge Object 是内部表示，不是独立持久化产物。** Knowledge Builder 的落盘只有 `.md`：
`knowledge-index.json` 由 Knowledge Compiler 从 `.md` 派生，`context-package.json` 由 Resolver 按任务生成。
`context.json` 是 Analyzer 产出的项目结构化上下文（技术栈/模块清单），是结构图 Producer 的输入，
**不属于** Knowledge Object 的存储层。

> **目录集合**：以 [`shared/schemas/knowledge-directories.yaml`](../../../shared/schemas/knowledge-directories.yaml) 为准。
> 哪个目录由谁产出、谁消费、是否进 index、必须写哪些 frontmatter，**一律以它为准**。
> 本文件**不列目录树**——派生的可读视图只有一处，在 [output-format.md](output-format.md) 的「固定产出结构」；
> 这里重复第三份清单正是历史上五处清单互相矛盾（directory 集合各不相同）的成因之一。
>
> 本节只保留**派生不出来**的三条语义：
> - `decisions/` 是 index 目标目录（契约 `indexed_by_compiler: true`），其文件**必须**写 `constraint:`
>   （契约 `compiler_enforced: [constraint]`）。**不要再把决策写进 `architecture/`**——那会被当作 pattern 索引。
> - `conventions/` 与 `observations/` **刻意不进 index**（契约 `indexed_by_compiler: false`）：
>   两者当前都是**人读产物**，没有机器消费者。**不要因为「没进 index」就跳过产出。**
> - `observations/` 里的 risk/antipattern **不要塞进 `graph.json`**：结构图只存结构事实
>   （见 [knowledge-access.md](../../../runtime/contracts/knowledge-access.md) 硬白名单）。
>   当前没有 risk 的机器链路；未来需要时再一次性闭环 Compiler→Resolver→context-package，并同步 schema/E2E。

## .md frontmatter（供 Resolver hydrate）

每个 patterns/components/api 的 .md 文件 frontmatter，除 `id`/`generatedBy`/`lifecycle`/`confidence` 外，
**必须写 `statement:`**——一句可执行的 convention/pattern 摘要。Resolver hydrate 直接抽它注入
context-package.json，Generator 不再读文件正文：

```yaml
---
id: patterns-table
statement: "列表页用 <统一表格> 包裹 + <schema表格> 声明式列配置渲染"
constraints: "分页 <分页参数> 数字；Element Plus 命名空间 <组件库前缀>"
anti_pattern: "不要手写 el-table + el-pagination"
tags: "table, list, search, workspace"
---
```

- `statement` = 一句 convention（Generator 直接注入，不读文件正文）——**必写**
- `constraints` = 逗号/分号分隔的硬约束（可选）
- `anti_pattern` = 什么不该做（可选）
- `tags` = 逗号分隔的标签（Resolver 用 tag 过滤/排序）——**推荐写**

没有 `statement` 时，Resolver 退化为「`# 标题` + `##` 节标题」拼接（仍可用，但不如 statement 精确）。

## Knowledge Objects（内部表示，不写入 graph.json）

```
Accepted Candidate
  → Knowledge Object（内部对象，knowledge-object.schema.json 校验）
  → .md（frontmatter statement/constraint）
  → Knowledge Compiler
  → knowledge-index.json
  → Knowledge Resolver
  → context-package.json
  → 下游 Skill
```

`knowledge-object.schema.json` 只校验这个**内部对象形态**，不是 `graph.json` 的 schema；
Knowledge Object **不落盘成 `knowledge-objects.json`**——不制造第三份知识权威。

```yaml
# 内部对象示例（不是 graph.json 的节点）
- id: pattern.repository
  type: pattern
  scope: project          # schema required：task=一次性, project=项目级, organization=企业级, personal=个人资产
  category: behavioral
  confidence: 0.94
  statement: "项目使用 Repository Pattern 封装数据访问"
  evidence:
    - { path: src/repositories/UserRepository.ts, type: file, lines: 45 }
    - { path: src/repositories/OrderRepository.ts, type: file, lines: 62 }
  related:
    - { id: principle.repository, relation: implements }
    - { id: api.user, relation: references }
  source: { extractor: pattern, verdict: accepted }
  occurrences: 17
  predictive_power: "Can answer: where to add data access for new entity?"
  obviousness: non-obvious
  tags: [repository, data-access, abstraction]
```

**落盘规则：**

| 对象 | 落点 | 生产者 | 说明 |
|------|------|--------|------|
| Knowledge Object | `.md` + frontmatter | Knowledge Builder | **唯一的持久化知识来源** |
| `knowledge-index.json` | `.project-knowledge/runtime/state/` | Knowledge Compiler | 从 `.md` 派生，不是 Builder 直接写 |
| `context-package.json` | `runtime/tasks/<task_id>/` | Knowledge Resolver | 按任务分桶注入 |
| `context.json` | `.project-knowledge/` | Analyzer | 项目结构化上下文；只把 `modules`/`layers` 喂给结构图 |
| `graph.json` | `.project-knowledge/` | Analyzer Post Processing | **只存结构事实**，白名单见 [knowledge-access.md](../../../runtime/contracts/knowledge-access.md) |

**下游消费方式**（知识走 context-package，结构才走 graph）：

- Planner：`context-package.json` 的 rules/knowledge/guidance；结构查询 `graph.json` 的 `findNode(module)`
- Architect：`context-package.json` 的 decisions；结构查询 `findDependencies` / `findConsumers`
- Generator：`context-package.json` 的 pattern/constraints；结构查询 `findNode(component/api)`
- Reviewer：`context-package.json` 的 rules/guidance；结构查询 `findImpacted` / `findConsumers`

> ⚠️ **不要**把 `pattern` / `convention` / `decision` / `risk` / `antipattern` 写成 `graph.json` 节点。
> 结构图的节点类型白名单、禁止字段与 `edges` 方向以
> [knowledge-access.md](../../../runtime/contracts/knowledge-access.md) 为唯一权威。

## Evidence Score Section

每个 .md 文件末尾附 Evidence Score 表：

```markdown
## Evidence Score

| Claim | Confidence | Occurrences | Verified | Evidence |
|-------|-----------|-------------|----------|----------|
| Repository Pattern | 0.91 | 18 | ✅ | src/repositories/ (18 files) |
| PascalCase convention | 0.95 | 380 | ✅ | 95% of components |
| ... | | | | |

Overall Confidence: 0.89
```
