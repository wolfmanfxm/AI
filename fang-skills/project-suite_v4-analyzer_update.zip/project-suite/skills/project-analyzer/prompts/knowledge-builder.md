# Knowledge Builder

> 从 Accepted Candidates 组装最终 `.project-knowledge/` 产出。

## Actions

1. 收集 Verifier 输出的所有 Accepted Candidates（含 confidence-adjusted）
2. 按知识类型分组（architecture / patterns / conventions / glossary / decisions / risks / antipatterns）
3. **逐组写入**最终 .md 文件——每组 Candidate 必须覆盖，不得跳过
4. 注入 Evidence Score Section（每个 Claim 的溯源）
5. 生成跨文件交叉引用

## Coverage Gate

**全部完成前不可退出。** 逐项验证：

| Candidate | 目标文件 | 验证方式 |
|-----------|---------|---------|
| directory.md | architecture/modules.md | 目录树 + 模块清单已合并 |
| framework.md | architecture/tech-stack.md | 技术栈表已写入 |
| architecture.md | architecture/overview.md | 分层+边界已写入 |
| patterns.md | patterns/*.md | 每种模式独立文件 |
| conventions.md | conventions/*.md | 每种规范独立文件 |
| glossary.md | architecture/glossary.md | 术语表已写入 |
| decisions.md | architecture/decisions.md | 决策记录已写入 |
| risks.md | observations/risks.md | 风险清单已写入 |
| antipatterns.md | observations/antipatterns.md | 反模式清单已写入 |
| principles.md | conventions/principles.md | Always/Never/Prefer/Avoid 已写入 |

**未覆盖的 Candidate → 返回重写对应文件 → 不可 Exit。**

## Output Structure

```
.project-knowledge/
├── architecture/
│   ├── overview.md          ← Directory + Architecture Extractor
│   ├── modules.md           ← Architecture Extractor
│   └── tech-stack.md        ← Framework Extractor
├── patterns/
│   ├── repository.md        ← Pattern Extractor
│   ├── composition.md       ← Pattern Extractor
│   └── ...
├── conventions/
│   ├── naming.md            ← Convention Extractor
│   ├── imports.md           ← Convention Extractor
│   └── directory.md         ← Convention Extractor
├── glossary.md              ← Glossary Extractor
├── decisions.md             ← Decision Extractor
├── risks.md                 ← Risk Extractor
├── antipatterns.md          ← AntiPattern Extractor
├── principles.md            ← Principle (from Convention+Pattern)
├── INDEX.md                 ← Index Generator
├── statistics.json
├── context.json
└── graph.json
```

## Evidence Score Section

每个 .md 文件末尾附 Evidence Score 表：

```markdown
## Evidence Score

| Claim | Confidence | Occurrences | Verified | Evidence |
|-------|-----------|-------------|----------|----------|
| Repository Pattern | 0.91 | 18 | ✅ | src/repositories/ (18 files) |
| PascalCase convention | 0.95 | 380 | ✅ | 95% of components |
| ... | | | | |

Overall Confidence: 0.89
```
