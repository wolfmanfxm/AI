# Knowledge Lifecycle

> `.project-knowledge/` 中的每个文件都有生命周期。不是"存在/不存在"的二元状态。
> Generator 只读 `accepted` — 不把猜测当事实。

## 状态机

```
                    ┌─────────┐
                    │  draft   │  ← Analyzer 初步生成
                    └────┬────┘
                         │
                   Reviewer / 人工确认
                         │
              ┌──────────┼──────────┐
              ▼                     ▼
        ┌──────────┐          ┌──────────┐
        │ verified │          │ archived  │  ← 确认有误 / 过时
        └────┬─────┘          └──────────┘
             │
       人工确认 / 多次验证
             │
             ▼
        ┌──────────┐
        │ accepted │  ← 可用于生产决策
        └────┬─────┘
             │
         过时 / 项目演进
             │
             ▼
        ┌──────────┐
        │ archived │
        └──────────┘
```

## 状态定义

| 状态 | 含义 | 谁可以读 | 谁可以改 |
|------|------|---------|---------|
| `draft` | Analyzer 初步分析，未经人工或 Reviewer 确认 | Planner（标注来源）、Analyzer（自身） | Analyzer（创建）、Reviewer（→verified/archived） |
| `verified` | Reviewer 或人工确认通过，但尚未达到生产级可信度 | Planner、Architect、Generator（标注来源） | Reviewer、人工 |
| `accepted` | 多方验证通过，可直接用于代码生成 | **所有 Skill** | 人工（降级需审批） |
| `archived` | 确认有误、过时、或不再适用 | 不读取（仅供追溯） | 任何 Skill（标注原因） |

## 使用规则

### Analyzer
- **产出时**：所有新知识文件标记为 `draft`
- **增量更新时**：已有 `accepted` 文件保持状态，仅更新内容并标记 `draft`（需重新验证）

### Planner
- **读**：`verified` + `accepted` 状态的知识
- **标注**：引用 `draft` 状态知识时，在 `# Context > 假设` 中显式标注

### Architect
- **读**：`accepted` 状态的架构知识、`verified` + `accepted` 的组件/模式
- **不读**：`draft` 状态的知识（可能不准确）

### Generator
- **读**：**仅 `accepted`** 状态的知识
- **理由**：代码生成是最下游，基于未验证的知识会产生生产级 bug
- **降级**：无 `accepted` 知识时，标注 `⚠️ 知识未验证`，使用通用模式

### Reviewer
- **职责**：将 `draft` → `verified` 或 `archived`
- **标准**：对照代码库验证知识准确性

### 人工
- **任何时候**可以将任何状态改为 `accepted` 或 `archived`
- **这是最高权限** — 覆盖所有自动判断

## knowledge.json 条目格式

```json
{
  "files": {
    "patterns/table.md": {
      "status": "accepted",
      "source": "project-analyzer",
      "verified_by": "human",
      "created": "2026-07-28T14:00:00",
      "updated": "2026-07-28T14:30:00",
      "verified_at": "2026-07-28T15:00:00",
      "confidence": 92,
      "notes": "Pattern matches 12/12 existing tables in codebase"
    }
  }
}
```

## 置信度与状态的联动

```
confidence ≥ 90 + verified → 建议 accepted
confidence 70-89 + verified → 保持 verified，建议人工确认
confidence < 70 → 保持 draft，建议 Reviewer 重新分析
```
