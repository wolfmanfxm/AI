---
name: project-reviewer
metadata: skill.yaml
description: >
  对代码变更进行五轴审查：正确性、安全性、可读性、架构、性能。问题分级（BLOCKER/HIGH/MEDIUM/LOW）
  附带精确的 file:line 引用和可操作的修复建议。
  触发词：代码审查、review、检查代码、审查 PR、代码质量、code review、security review、
  audit code、审查、帮我看看这段代码、这个 PR 怎么样。
  产出：REVIEW.md（分级问题列表 + 正向反馈 + 审查结论）。
---

# Reviewer

> 代码变更 + Acceptance Criteria + Risk Assessment → 五轴审查 → 问题分级 → REVIEW.md

## 核心原则

1. **精确引用** — 每个发现标注 `file:line`
2. **AC 对照** — 逐条验证 `PLAN.md > # Acceptance Criteria`
3. **可操作** — 每个问题附带具体修复建议
4. **分级明确** — BLOCKER 必须有明确阻断理由

## 职责边界

→ [references/boundary.md](references/boundary.md)

> 🔴 reviewer 只查不修。发现问题 → 记录 file:line + 建议。对照 Scope 检查范围蔓延。

## 前置条件

| 优先级 | 资源 | 缺失时 |
|--------|------|--------|
| 0 | **变更 Code**（diff / 文件列表）| 🔴 BLOCKED — 拒绝执行 |
| 1 | **`PLAN.md > # Acceptance Criteria`** | DEGRADED — 标注"⚠️ 无验收标准" |
| 2 | **`PLAN.md > # Risk Assessment`** | DEGRADED — 标准审查强度 |
| 3 | **`PLAN.md > # Scope`** | DEGRADED — 无法检查范围蔓延 |
| 4 | `.project-knowledge/patterns/` | 标注"⚠️ 缺乏项目规范" |
| 5 | `PLAN.md > # Task Breakdown` | 不阻塞 — 判断是否超出规划范围 |
| 6 | `ARCHITECTURE.md` | 不阻塞 — 对照决策检查一致性 |

## 审查轴

| 轴 | 重点 |
|----|------|
| 正确性 | 逻辑错误、边界条件、类型安全、状态一致性、API 契约 |
| 安全性 | 注入、XSS、敏感数据、权限、输入校验 |
| 可读性 | 命名、复杂度、注释、函数长度 |
| 架构 | 模块边界、接口设计、复用、扩展性 |
| 性能 | N+1 查询、渲染、内存、包体积 |

## 问题分级

| 级别 | 判定 |
|------|------|
| 🔴 BLOCKER | 生产事故 → 必须修复 |
| 🟠 HIGH | 大概率引发线上问题 |
| 🟡 MEDIUM | 代码质量可改善 |
| 🟢 LOW | 锦上添花 |
| 🔵 PRAISE | 值得学习 |

## 工作流

1. 读 `PLAN.md > # Acceptance Criteria` + `# Risk Assessment` + `# Scope`
2. 按 Risk Assessment 确定审查强度（HIGH→Full audit / MEDIUM→Spot check / LOW→Standard）
3. 🔴 CHECKPOINT → [checkpoint 模式](../../shared/conventions/checkpoint-pattern.md)
4. 五轴扫描 → 逐条对照 AC 验证 → 检查 Scope 边界
5. 输出 `reports/REVIEW-<topic>.md`

失败处理 → [references/failure-handling.md](references/failure-handling.md)

## 完成后下一步

```
reviewer 完成 → /project-generator(修复) 或 /project-documenter 或 /project-releaser
```
