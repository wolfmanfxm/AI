# Execution — Planner

> @template: execution
> Session Snapshot: 每步 Pipeline 后写入 `.project-knowledge/.sessions/project-planner/state.json` → 跨 session resume

## Actions

9 步 Pipeline，每步产出对应 PLAN.md 的一个 Section：

| # | 步骤 | 产出 Section | 核心动作 |
|---|------|-------------|---------|
| 1 | Goal 定义 | `# Goal` | 一句话 Goal + 成功标准 |
| 2 | Scope 边界 | `# Scope` | IN/OUT 清单 + 边界说明 |
| 3 | Context 引用 | `# Context` | context.json 关键信息摘要 + 假设表 |
| 4 | Reuse Analysis | `# Reuse Analysis` | 可复用组件/API/模式清单 + 复用方式 |
| 5 | Decision 识别 | `# Decision` | 待决策点列表 + 每个决策影响哪些 Task |
| 6 | Task Breakdown | `# Task Breakdown` | Task 列表（vertical slice 默认 + horizontal task 例外，每 Task 含 task_type / slice_goal/demo 或 reason/blocks/verification / 估时 / 依赖 / AC / 风险） |
| 7 | Dependency Graph | `# Dependency Graph` | 任务依赖图（拓扑序，标注并行机会） |
| 8 | Risk Assessment | `# Risk Assessment` | Top-3 风险 + 缓解措施 + 置信度 |
| 9 | Acceptance Criteria | `# Acceptance Criteria` | 可证伪的 AC 列表（每条含 base-state + falsify） |

→ 详细 Prompt：[prompts/task-breakdown.md](task-breakdown.md)
→ 工作量评估：[prompts/estimation.md](estimation.md)

🔴 CHECKPOINT — 展示 PLAN.md 摘要（任务数+估时+风险TOP3）
⚡ 写入 session snapshot: `current_step` + `completed_sections` → 中断后从此步骤 resume

## Decision Record

每个决策输出标准化 Decision Record：

```yaml
decisions:
  - id: D-001
    decision: "模块划分: 新建 <目标模块>/"
    selected: "<目标模块>/"
    ignored:
      - { option: "扩展 <已有模块>/", reason: "<已有模块> 已有 <N> 文件(top<M>), 耦合风险高" }
      - { option: "新建 <其他模块>/", reason: "太泛, 未来可能包含非目标功能" }
    reason: "<目标功能>是独立业务域, 与<已有功能>职责不同"
    evidence: ["<已有模块>/ <N> files", "<其他模块> <M> files (独立模块)"]
    confidence: 0.85
    risk: "<已有功能>集成需确认"
    owner: "architect"
```

## Verification（Candidate 验证子流程，**非 Stage**）

本阶段的产出先作为 **Candidate**，在 Exit 前加载 [verifier.md](verifier.md)，以 fresh context 执行独立验证；
只有 verifier 判为 **Accepted** 的 Candidate 才能进入 `validation` 阶段或被下游消费。

> 依据 `skill.yaml` 的 `verification: { mode: candidate-verify-accept }` → 见
> [workflow-protocol · Verification Contract](../../../workflow-protocol/SKILL.md)。
> ⚠️ verify **不是** stage：它不参与 stage progression，也不出现在 `interface.stages` 里。

## Exit

- 9 个 Section 全部非空（内容 ≥3 行）
- confidence ≥ 40%（否则仅输出 Goal+Scope+Gap List，拒绝产出完整 PLAN）
- Reasoning Report 已生成
- 用户已确认摘要

## Failure

| Condition | Action |
|-----------|--------|
| 需求自相矛盾 | 在 Context 假设表中标注，分别给出两个方案覆盖矛盾分支 |
| 时间不可行（估时远超可用工时） | 给出最小可行版 + 完整版两个方案，AskUserQuestion |
| Confidence < 40% | **拒绝产出完整 PLAN**，只输出 `# Goal` + `# Scope`（含 Gap List）→ [confidence-gate](../../../runtime/mechanisms/confidence-gate.md) |
| 用户中途修改需求范围 | 重新划定 Scope，废弃任务标 `[deprecated]` |
