# Suite Spec v1.0.0

> Project Suite 的正式 Framework 规范。

---

## 0. 权威层级（单一 Source of Truth）

避免多头权威。每个事实只有一个手工维护的源：

| 层级 | 文件 | 定位 | 维护方式 |
|------|------|------|---------|
| **单一权威** | `skills/*/skill.yaml` | Skill Contract（intrinsic：description/capabilities/produces/consumes/boundary/interface…） | 手工，唯一源 |
| **编排权威** | `runtime/config/scheduler.yaml` | skill_order.decision_order / priority（路由 + 调度顺序） | 手工 |
| **编排权威** | `runtime/registry/workflow-library.yaml` | workflow 编排（pipeline 定义） | 手工 |
| **编排权威** | `runtime/config/profiles.yaml` | profile（任务复杂度 → skill 激活范围 + auto_advance） | 手工 |
| **门禁权威** | `runtime/config/rules.yaml` | gate（conf pass/review/block 阈值）+ 执行前置条件 | 手工 |
| **门禁权威** | `runtime/config/gates.yaml` | **维度**门禁（knowledge / coverage / safety / release / decisions / findings）——**不含 conf 阈值** | 手工 |
| **执行策略** | `runtime/config/skill-policy.yaml` | rollback / recovery / reliability / stage_config | 手工 |
| **派生（勿手改）** | `runtime/registry/*.yaml`（4 份：skills.generated / skill-catalog / capabilities / capability-routing） | 从 skill.yaml 生成 | `generate-registry.mjs` |

**规则**：
- `description/capabilities/produces/consumes/boundary/interface…` 以 `skill.yaml` 为准。
- `gate`（conf 阈值）以 `runtime/config/rules.yaml` 为准；`rollback/recovery/reliability/stage_config` 以 `runtime/config/skill-policy.yaml` 为准。
- `priority/decision_order` 以 `scheduler.yaml` 为准。
- 并行关系由 produces/consumes 推导的 **Capability DAG** 决定（能力依赖，非强制执行顺序），不再是 skill 固定字段。
- 派生文件与 skill.yaml 不一致 → `generate-registry.mjs --check` 报漂移（exit 1）。

**I/O 三层（易混淆，勿强制相等）**：

`skill.yaml` 里出现"三个 consumes"不是重复，是三个不同视图：

| 层 | 载体 | 权威内容 | 用途 |
|----|------|---------|------|
| **Interface** | `skill.yaml` `interface.inputs/outputs` | 具体输入/输出（type / required / source） | Skill 执行契约（Host 前置检查 + LLM） |
| **Capability** | `skill.yaml` 顶层 `produces/consumes` | 能力类型（KnowledgeBase / Code / Plan…） | DAG / Skill 依赖 |
| **Artifact** | `artifact-types.yaml` `types` + `mapping` | artifact type + producer / consumer | 数据路由 |

> **一句话边界**：knowledge 是持久化知识资产；knowledge-index 是 Compiler 内部索引；context-package 是下游 Skill 的正式知识注入接口；test 和 release 是业务 Artifact 类型，而不是把其中的某个文件/字段拆成新的类型。

> 例：analyzer 的顶层 `consumes: []`（无上游依赖）与 `artifact-types.yaml` 的 `consumes: [implementation]`（输入类型）是**两个不同事实**，不矛盾、不要统一。详见 [ADR-004](docs/decisions/ADR-004-four-layer-io-boundaries.md)。
> 语义一致性由 `shared/scripts/check-io-connectivity.sh` 验证——只查「能接通」（type 合法、source→produces 断链、output 有对应 Capability），不查「完全相等」。

### 0.1 Runtime Reachability（可执行性契约）

> **任何「声明存在的行为」，都必须能沿 Host 的真实执行路径找到入口；仅有文件、配置、计数、静态 ✅ 都不算可执行。**
>
> **且：光有入口不够——至少要有一个失败用例能证明它真的被执行了。**
> 「检查器打印 ✅」只证明它没报错，不证明它有判别力；**能接通的说接通、接不通的也必须报错**，
> 才算执行过。故每条新增断言都要求配一个「应被拦下」的 fixture（例：`check-io-connectivity.sh`
> 文件尾的自检段——用断链/合法两个 fixture 双向证明自己有判别力）。

**逆命题同样成立**：只被静态工具消费、**不被运行时消费**的声明，要么给它运行时入口，要么删掉。

**退役契约的落点规则（2026-09-20 补）**：

> Retired Contract may exist in history/archive, but **MUST NOT** be referenced by any
> executable path, active schema, active configuration, generated artifact, or Host execution instruction.

即：**退役声明只允许落在历史区**——`docs/roadmap.md`、`docs/archive/`、ADR 的历史/迁移说明、git 历史。
**出现在下列任一位置即算失败**：`skills/*/skill.yaml`、`skills/*/SKILL.md`、`shared/scripts/`、
`*.generated.*`、`runtime/config/`、active schema、Host 执行指令（prompt / stage-template / adapter）、
`runtime/context/` 的 active 文件。

**为什么单列一条**：它比「零消费者」更严。零消费者只能证明**删了不会坏**，证明不了
**它没有在暗示自己仍然存在**。2026-09-20 清退「Context Engine 契约」族（字段块 + 引擎规格，见
[roadmap G1.1](docs/roadmap.md)）时，关键词扫描早已全绿，逐类语义复查仍揪出三处复述旧语义——
本规范 §3.1 的一处字段墓碑、`check-yaml.sh` 注释里的文件名、以及归档 `.md` **正文仍是现在时执行语态**
（"所有 Skill 统一按此栈加载上下文" / "缺失任一项 → 下游 skill BLOCK，拒绝执行"）。
**故清场验收必须做两遍：先按精确关键词 grep 定位，再逐条读命中处是不是仍在描述当前行为。**
（本条规则自身即不写退役名，以保证「活跃文件命中数 = 0」这条不变式无需自我豁免。）
搜精确关键词，**不要搜 `context`**——`runtime/context/` 里的 `context.md` / `context-resolution.md`
是**活的 Context Protocol**（描述产物及其 LLM 处置规则），与要清退的 Context **Engine** 是两回事。

**为什么把它抬成一等原则**：2026-09-18 一轮排查挖出的问题**全是这一条的实例**——

| 实例 | 表面状态 | 实际 |
|------|---------|------|
| `constraint` 字段（round11/13） | 字段写了、diff 能验证 | 编译器前 15 行硬窗口 → 字段在后段则**读不到** |
| `verification.mode`（10/10 skill.yaml） | 声明齐全、取值一致 | **零消费者**：无 schema、无脚本读它 |
| 幽灵 Verify 阶段（8/10） | SKILL.md 写了 `Verify` 行、`verifier.md` 存在 | 不在 `interface.stages` 的路径上 → **运行时永不被加载** |
| `artifact-types.location` | 每类产物都有落点声明 | **零脚本解析**；漂移只能靠人眼 |
| `check-drift` Drift 1/2/5 | 打印 ✅ | **没有任何比对**（假检查） |

它们各自看起来都「已完成」——**文件在、配置在、计数对、检查绿**——但没有一条能沿 Host 的路径走到。

**落地三要求**：
1. **新增声明/机制时，必须能回答「Host 在哪一步读它」**；答不上来 → 不进核心（与 [eval-contract.md](docs/eval-contract.md) 的 ablation 义务配套）。
2. **断言必须能失败**：写完检查后要构造一个应被拦下的输入，确认它真的红——不能失败的断言 = 假 ✅。
3. **派生物必须有 `--check`**：`generate-registry.mjs` / `generate-skill-ir.sh` / `knowledge-directories.generated.sh` 缺漂移检测时，陈旧不可见。

**它不解决什么（如实标注）**：本原则是**治理约定**，无机器强制。上面每条实例的修复都附带了具体断言（G19 / E2E §6 / 新 Drift 2 等），但「Host 是否真的执行」最终仍属 Host 能力（见 [host-capability.md](runtime/contracts/host-capability.md)）——Suite 不假装有强制力。

---

## 1. 目录结构契约

每个 skill 必须包含以下目录和文件：

```
skills/<skill-name>/
├── SKILL.md              🔴 REQUIRED    skill 主文件（路由 + 工作流 + 引用索引）
├── skill.yaml            🔴 REQUIRED    统一元数据（id/version/produces/consumes/depends/boundary）
├── prompts/              🔴 REQUIRED    维度/步骤 Prompt（至少 1 个）
│   └── main.md           🟡 IMPORTANT  默认 Prompt（若只有一个则为它）
├── references/           🔴 REQUIRED    详细指引（至少 2 个）
│   ├── boundary.md       🔴 REQUIRED    职责边界 + 反例黑名单（≥3 条）
│   ├── trigger-words.md  🟡 IMPORTANT  触发词列表
│   └── ...               🟢 OPTIONAL    code-audit / self-check 等
└── (无其他目录)           🔴 REQUIRED   禁止 scripts/ assets/ 等非标准目录
```

### 目录检查

```
🔴 缺失 → BLOCK，skill 不可发布
🟡 缺失 → WARN，skill 降级为 Scaffold
🟢 缺失 → INFO，不影响发布
```

---

## 2. SKILL.md 契约

### 2.1 Frontmatter（🔴 REQUIRED）

```yaml
---
name: <kebab-case>          # 必须与目录名一致
metadata: skill.yaml        # 引用统一元数据
description: >              # 做什么 + 触发词（discoverability），≤1024 字符；产出契约见 skill.yaml produces
  触发词: ...
---
```

### 2.2 内容结构（🔴 REQUIRED，顺序可调但必须包含）

| 章节 | 要求 |
|------|------|
| `# 标题` | 一行摘要，格式 `> 输入 → 过程 → 输出` |
| `## 核心原则` | 3-4 条，每条一句 |
| `## 职责边界` | 引用 `[references/boundary.md]` + 一行 🔴 警示 |
| `## 前置条件` | 优先级表：0=context.json, 1..N=其他 |
| `## 工作流` | Discover → Execute → Output 三段式 |
| `> 完成后：` | 下游 skill 路由建议 |
| `## 引用索引` | 表格：资源名 + 路径 |

### 2.3 CHECKPOINT（🔴 REQUIRED）

- 至少 **1 个** `🔴 CHECKPOINT` 标记
- 每个 CHECKPOINT 使用 `AskUserQuestion`（引用 `shared/conventions/checkpoint-pattern.md`）
- CHECKPOINT 位置：Discover 完成后（确认范围）、Execute 关键决策前（确认方案）

---

## 3. skill.yaml 契约

### 3.1 字段（🔴 REQUIRED）

```yaml
id: <kebab-case>            # 与目录名一致
version: "<semver>"         # 遵循 semver
mode: Production            # Scaffold | Production | Library | Governed
owner: project-suite        # 固定
produces: [<Capability>+]   # 产出的能力类型（Capability Requirement 的供给侧）
consumes: [<Capability>*]   # 消费的能力类型（Capability Requirement 的需求侧，依赖由它推导）
requires: [<resource>*]     # 运行前提（agent 类型/外部依赖）
boundary: <string>          # 一行职责边界
```

> 已移除字段（ADR-003）：`priority`（→ scheduler.yaml skill_order）、`depends_on`/`parallel_with`（→ produces/consumes 推导的 Capability DAG）。skill 不声明「依赖哪个 skill」，只声明「需要什么能力」——依赖关系由 produces/consumes 推导。

### 3.2 版本兼容声明（→ suite 级，不在 skill.yaml）

> **2026-09-20 修正**：本节此前要求**每个 skill** 声明 `compatibility:` 块（🟡 IMPORTANT + 「必须声明」），
> 与 [ADR-003](docs/decisions/ADR-003-skill-contract-vs-orchestration.md) 的权威映射表**直接冲突**——
> ADR-003 白纸黑字：「版本兼容约束 → `compatibility.yaml` 的 `matrix`，**不是** skill.yaml」。
> 实测该块 **0/10 声明**，且 G1–G17 无一项覆盖它，于是「10 个 skill 全部不遵守 MUST」全仓绿灯。
>
> 现已删去 skill 级要求，**兼容性单一承载于 `runtime/registry/compatibility.yaml`**（含 `current` 版本登记
> 与 `matrix` 兼容矩阵，由 `check-consistency.sh` 的 L3 真实消费）；
> suite 级最低要求见 `suite-manifest.yaml` 的 `compatibility:` 块。
> **不为「让规范和 skill.yaml 一致」去补 10 份声明**——那是新增一份无消费者的权威。


上游 schema 变更（如 context.json 新增 REQUIRED 字段）→ 下游 skill 的 `context_schema` 版本跟进。

### 3.3 Capability 类型枚举（🔴 REQUIRED，不可自定义）

> 单一源：`runtime/registry/capabilities.yaml` 的 `capability_types`（generate-registry.mjs 生成）。此处为同步快照，以 capabilities.yaml 为准。

```
KnowledgeBase | KnowledgeIndex | Context | State | Graph | Plan | Architecture | Code | Test | Review |
RefactoredCode | Documentation | Release | PipelinePlan | Recommendation
```

> **advisory 能力**（当前仅 `Recommendation`）：建议类能力，`capability_types` 中标注 `advisory: true`。
> 在 Capability DAG 中不构成硬依赖边——`dependency_graph` 里归入 `needs_advisory`（而非 `needs`），缺失不阻塞下游。
> 语义：KnowledgeBase/Context/Graph 是「没有就无法正确工作」的必需能力；Recommendation 是「有则更好」的建议能力。

---

## 4. boundary.md 契约

### 4.1 职责表（🔴 REQUIRED）

```markdown
| ✅ 本阶段职责 | ❌ 禁止操作 |
|-------------|-----------|
| ≥3 行        | ≥3 行      |
```

### 4.2 反例黑名单（🔴 REQUIRED）

```markdown
## 反例黑名单

| # | ❌ 反模式 | 为什么不要做 | ✅ 正确做法 |
|---|---------|-------------|-----------|
| 1 | ...     | ...         | ...        |
| 2 | ...     | ...         | ...        |
| 3 | ...     | ...         | ...        |
```

≥3 条反例，每条对应真实踩坑记录。禁止泛泛而谈的"不要写得不好"。

---

## 5. Suite 级别契约

### 5.1 全局 Shared 资源

| 资源 | 路径 | 用途 |
|------|------|------|
| CHECKPOINT 模式 | `shared/conventions/checkpoint-pattern.md` | 统一 AskUserQuestion 调用格式 |
| Vault 同步协议 | `shared/conventions/vault-sync.md` | analyzer + documenter 引用 |
| Evidence Header | `shared/templates/evidence-header.md` | .md 产出文件的 Frontmatter 模板 |

### 5.2 Runtime 协议

| 协议 | 路径 | 所有 skill 必须遵循 |
|------|------|-------------------|
| Project State | `runtime/state/state.md` | ✅（读写 .project-knowledge/runtime/state.json） |
| Knowledge Lifecycle | `runtime/state/schemas/knowledge-lifecycle.md` | ✅（Generator 只读 accepted；Reviewer 验证 Candidate） |
| Knowledge Index | `runtime/state/schemas/knowledge-index.md` | ✅（analyzer 生成，下游按 capability 查询） |
| Confidence Gate | `runtime/mechanisms/confidence-gate.md` | ✅（confidence → Gate 行为：PASS/REVIEW/GATE/BLOCK） |
| Timeline | `runtime/metrics/timeline.md` | ✅（所有 Skill 追加执行指标到 timeline.json） |
| Knowledge Health | `runtime/metrics/knowledge-health.md` | ✅（analyzer 增量模式自动检测知识库质量） |
| Unified I/O | `runtime/contracts/skill-io.md` | 🟡（建议遵循，非强制） |
| 状态机 | `runtime/mechanisms/state-machine.md` | ✅ |
| 断点续传 | `runtime/mechanisms/checkpoint.md` | ✅（manifest.json 读写） |
| DAG 调度 | `runtime/mechanisms/scheduler.md` | ✅（按 capabilities.yaml 优先级） |
| Context Protocol | `runtime/context/context.md` | ✅（下游 skill 读 context.json） |
| 能力注册 | `runtime/registry/capabilities.yaml` | ✅（定义 produces/consumes） |
| Workflow 模板 | `runtime/registry/workflow-library.yaml` | 🟢（Pipeline 模式，用户是 Dispatcher） |

---

## 6. 质量门禁

### 6.1 门禁检查清单

| # | 检查项 | 级别 | 验证方式 |
|---|--------|------|---------|
| G1 | SKILL.md 存在且 ≤130 行 | 🔴 | `wc -l` |
| G2 | skill.yaml 存在且字段完整（含 `interface:` 块） | 🔴 | YAML 解析 + 字段校验 |
| G3 | boundary.md **或** SKILL.md 内嵌反例 ≥3 条 | 🔴 | 搜索 `❌` 计数（两处之和） |
| G4 | 至少 1 个 `CHECKPOINT`（SKILL.md 或 prompts/） | 🔴 | 搜索 `CHECKPOINT` |
| G5 | 职责边界表 ≥3 行 ✅/❌ | 🔴 | 搜索 `✅ 本阶段职责` |
| G6 | frontmatter 含 `description` + 触发词（产出契约在 skill.yaml produces） | 🔴 | YAML 解析 |
| G7 | capabilities.yaml 中已注册 | 🟡 | grep skill id |
| G8 | `完成后` next-step hint 存在 | 🟡 | 搜索 |
| G9 | boundary.md 含失败兜底 | 🟡 | 搜索 |
| G10 | 无 runtime-specific 措辞 | 🟡 | grep `在 Claude Code` |
| G11 | prompts/ 至少 1 个文件 | 🟢 | `ls` |
| G12 | references/ 至少 2 个文件 | 🟢 | `ls` |
| **G13** | **每个 `stages:` 声明有对应 `prompts/<stage>.md`** | 🔴 | 对比 skill.yaml stages 与 prompts/ 文件 |
| **G14** | **每个 stage prompt 含 `@template:` 声明** | 🔴 | 搜索 `@template:` |
| **G15** | **`skill-policy.yaml` 含 rollback** | 🔴 | grep `rollback:` skill-policy.yaml |
| **G16** | **Skill Atlas 条目完整** | 🟡 | 检查 `docs/skill-atlas.md` 含该 Skill |
| **G17** | **last_reviewed 在 review_cadence_days 内** | 🟡 | 对比当前日期与 skill.yaml `last_reviewed` |

### 6.2 模式分级

| 模式 | 门禁要求 |
|------|---------|
| **Governed** | G1-G17 全部 🔴🟡 通过 + trust report + quality scorecard + 独立 judge + 实测验证 |
| **Production** | G1-G16 全部 🔴🟡 通过 |
| **Scaffold** | G1-G6 全部 🔴 通过 |

---

## 7. 合规验证

自动验证（`shared/scripts/check-conformance.sh`）：

```
check_suite_compliance()
  → 读取所有 skill 的 SKILL.md + skill.yaml + boundary.md + prompts/
  → 按 G1-G16 逐项检查
  → 输出 PASS/WARN/FAIL + 修复建议
```

触发词评测（`shared/scripts/trigger-eval.mjs`）：

```
trigger_eval()
  → 读取所有 skill.yaml 的 triggers_cn / triggers_en
  → 检测重叠（>1 skill 共享同一触发词）
  → 检测缺失（无触发词的 skill）
  → 输出 trigger-eval-report.md
```

---

## 8. Governed Package Boundary

> yao-meta-skill Governed 模式要求。所有 Production 模式 Skill 建议满足，Governed 模式 Skill 必须满足。

### 8.1 要求清单

| Requirement | 对应文件 |
|-------------|---------|
| `owner` | skill.yaml `owner:` 字段 |
| `review cadence` | 每个 SUITE_SPEC 版本 bump 时审查 |
| `input_files` (file-backed fixture) | skill.yaml `interface.inputs` |
| `output contract` | skill.yaml `interface.outputs` |
| `rollback boundary` | `runtime/config/skill-policy.yaml` 的 rollback |
| `trust report` | `reports/trust-report.md` |
| `output_quality_scorecard` | `reports/output-quality-scorecard.md` |

### 8.2 Missing Evidence

以下项当前不可获取，标记为 `missing evidence`（不伪造）：

- **telemetry**: Skills 运行在 Claude Code 会话中，无集中式指标采集
- **approvals**: User-as-Dispatcher 模式，人在 CHECKPOINT 处审批
- **metrics**: 无自动化质量指标流水线
- **benchmarks**: 无标准化 skill 产出质量基准测试套件
- **drift detection**: 无自动检测 skill 偏离其契约的机制
```
