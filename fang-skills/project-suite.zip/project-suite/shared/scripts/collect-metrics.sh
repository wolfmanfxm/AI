#!/bin/bash
# Telemetry Collector v1.0
# Aggregates execution metrics from .project-knowledge/runtime/ across sessions.
# No external service needed — reads local state files.
#
# Usage: bash shared/scripts/collect-metrics.sh [project-root]
# Output: reports/telemetry-report.md

set -euo pipefail
PROJECT_ROOT="${1:-.}"
RUNTIME_DIR="$PROJECT_ROOT/.project-knowledge/runtime"
STATE_FILE="$RUNTIME_DIR/state.json"
TIMELINE_FILE="$RUNTIME_DIR/timeline.json"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SUITE_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
REPORT_DIR="$SUITE_ROOT/reports"
mkdir -p "$REPORT_DIR"

REPORT="$REPORT_DIR/telemetry-report.md"
TODAY=$(date +%Y-%m-%d)

# ═══ Guard: 前置检查 RUNTIME_DIR（2026-09-20 修）═══
#
# 为什么需要：本脚本对**没有 .project-knowledge/runtime/ 的项目**运行时，此前会 **静默 exit 1**
#   （stdout/stderr 全空、不留报告），根因是两个抑制器合谋——
#   `manifest_count=$(find "$RUNTIME_DIR" … 2>/dev/null | wc -l)`：
#   ① `2>/dev/null` 吞掉 find 的报错；② `set -o pipefail` 让 find 的 exit 1 穿透管道；
#   最终 `set -e` 在无声中终止脚本。CI 里表现为「任务失败但无任何日志」。
#
# 处理原则：**响亮失败，而不是把「没有数据」伪装成「0 次执行」**——
#   后者正是本项目一直在清理的「假绿」问题（见 docs/roadmap.md G3）。
if [ ! -d "$RUNTIME_DIR" ]; then
  echo "❌ collect-metrics: 未找到 $RUNTIME_DIR" >&2
  echo "   该项目尚未执行过任何 skill，没有可采集的遥测数据。" >&2
  echo "   当前 project-root: $(cd "$PROJECT_ROOT" 2>/dev/null && pwd || echo "$PROJECT_ROOT")" >&2
  echo "   用法: bash shared/scripts/collect-metrics.sh <project-root>" >&2
  exit 1
fi

# ═══ Collect data ═══

# 1. Execution history from state.json
if [ -f "$STATE_FILE" ]; then
  # ⚠️ 不要写 `$(grep -c X f || echo 0)`：零匹配时 grep 已打印 0 且 exit 1，`|| echo 0` 再补一个
  #    → 变量成两行 `0\n0` → 指标数字报错/失真（2026-09-18 修）
  total_executions=$(grep -c '"skill"' "$STATE_FILE" 2>/dev/null || true); total_executions=${total_executions:-0}
  completed=$(grep -c '"status": "completed"' "$STATE_FILE" 2>/dev/null || true); completed=${completed:-0}
  partial=$(grep -c '"status": "partial"' "$STATE_FILE" 2>/dev/null || true); partial=${partial:-0}
  blocked_count=$(grep -c '"BLOCK' "$STATE_FILE" 2>/dev/null || true); blocked_count=${blocked_count:-0}

  # Avg confidence (extract numbers, average)
  confidences=$(grep -o '"confidence": [0-9]*' "$STATE_FILE" 2>/dev/null | grep -o '[0-9]*' || echo "")
  if [ -n "$confidences" ]; then
    sum=0; count=0
    for c in $confidences; do sum=$((sum + c)); count=$((count + 1)); done
    avg_confidence=$((sum / (count > 0 ? count : 1)))
  else
    avg_confidence=0
  fi

  # Skills used
  skills_used=$(grep -o '"skill": "[^"]*"' "$STATE_FILE" 2>/dev/null | sed 's/.*"\(.*\)".*/\1/' | sort -u | tr '\n' ',' | sed 's/,$//')
else
  total_executions=0; completed=0; partial=0; blocked_count=0; avg_confidence=0; skills_used=""
fi

# 2. Timeline metrics
if [ -f "$TIMELINE_FILE" ]; then
  total_timeline_entries=$(grep -c '"startedAt"' "$TIMELINE_FILE" 2>/dev/null || true); total_timeline_entries=${total_timeline_entries:-0}

  # Extract durations (finishedAt - startedAt in seconds, if both present)
  durations=$(node -e '
const fs = require("fs");
let entries; try { entries = JSON.parse(fs.readFileSync(process.argv[1], "utf8")); } catch { entries = []; }
const list = Array.isArray(entries) ? entries : [];
const ds = [];
for (const e of list) {
  if (e.startedAt && e.finishedAt) {
    const s = Date.parse(e.startedAt), f = Date.parse(e.finishedAt);
    if (!isNaN(s) && !isNaN(f)) ds.push((f - s) / 1000);
  }
}
if (ds.length) {
  const min = Math.min(...ds), max = Math.max(...ds), avg = ds.reduce((a, b) => a + b, 0) / ds.length;
  console.log(`${Math.round(min)} ${Math.round(max)} ${Math.round(avg)} ${ds.length}`);
} else {
  console.log("0 0 0 0");
}
' "$TIMELINE_FILE" 2>/dev/null || echo "0 0 0 0")
  read min_dur max_dur avg_dur dur_count <<< "$durations"
else
  total_timeline_entries=0; min_dur=0; max_dur=0; avg_dur=0; dur_count=0
fi

# 3. Manifest stats (check if any manifests exist)
manifest_count=$(find "$RUNTIME_DIR" -name "manifest.json" 2>/dev/null | wc -l | tr -d ' ')

# ═══ Write report ═══

cat > "$REPORT" << EOF
# Telemetry Report

> Generated: $TODAY | Source: \`.project-knowledge/runtime/\` | No external service

## Summary

| Metric | Value |
|--------|-------|
| Total executions | $total_executions |
| Completed | $completed |
| Partial/Interrupted | $partial |
| Blocked (confidence gate) | $blocked_count |
| Avg confidence | ${avg_confidence}% |
| Skills used | ${skills_used:-none} |

## Duration (seconds)

| Metric | Value |
|--------|-------|
| Samples with timing | $dur_count |
| Min duration | ${min_dur}s |
| Max duration | ${max_dur}s |
| Avg duration | ${avg_dur}s |

## Timeline

| Metric | Value |
|--------|-------|
| Total timeline entries | $total_timeline_entries |
| Manifest files | $manifest_count |

## Missing Evidence (not collectable without external service)

| Item | Reason |
|------|--------|
| Token usage per session | Claude Code sessions don't expose token counts to file system |
| User satisfaction | No survey mechanism |
| Session count per day | No centralized counter |
| Concurrent sessions | No session registry |
| Error rate by type | Error details stay in session transcripts, not written to state |

## Interpretation

- **Confidence trend**: avg ${avg_confidence}% — $(if [ "$avg_confidence" -ge 80 ]; then echo "healthy"; elif [ "$avg_confidence" -ge 60 ]; then echo "needs attention"; else echo "critical"; fi)
- **Reliability**: $completed/$total_executions completed ($(( total_executions > 0 ? completed * 100 / total_executions : 0 ))%)
- **Interruptions**: $partial partial/interrupted executions — checkpoint protocol should enable resume

---

> This report is generated locally from \`.project-knowledge/runtime/\` files.
> For cross-project or team-level aggregation, feed this data into your observability stack.
EOF

echo "Telemetry report: $REPORT"
echo "  Executions: $total_executions | Completed: $completed | Avg confidence: ${avg_confidence}%"
echo "  Skills: ${skills_used:-none}"
