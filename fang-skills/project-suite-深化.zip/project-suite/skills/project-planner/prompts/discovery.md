# Discovery — Planner

> @engine: discovery

## Actions

0. **Context Resolver** — 查询 knowledge-graph.yaml → 注入 curated knowledge：
   → [Context Resolver](../../../runtime/contracts/context-resolver.md)

1. **Completeness Check** → [prompts/completeness-check.md](completeness-check.md)：
   - 多维度评分（goal/scope/constraints/knowledge）→ planning_confidence
   - ≥0.9 → 直接 Generate Plan（简单任务不走重流程）
   - 0.7-0.89 → Light Interview（≤2 questions，只问关键缺口）
   - 0.5-0.69 → Standard Interview（≤3 questions，逐轮追问）
   - <0.5 → Deep Interview + Planning Loop（≤5 questions, 用完后 Assumption）
   - Context Resolver 已回答的 → 不重复问

2. 结构化查询项目知识：`@adapter:knowledge.query --type component,api,pattern --scope project`

3. 读用户输入 + 上游 `PLAN.md` / `ARCHITECTURE.md`（若存在）

4. 一句话总结 **Goal** + 划定 **Scope** 边界（显式列出 包含/不包含）

5. CHECKPOINT — 展示 Goal + Scope（格式：一句话 Goal + Scope IN/OUT 清单）

## Exit

- Goal 一句话已确认
- Scope 边界已确认（IN/OUT 清单无异议）
- 用户已点确认

## Failure

| Condition | Action |
|-----------|--------|
| 无任何需求输入 | 🔴 BLOCKED — 拒绝执行 |
| `context.json` 缺失 | 从 `.project-knowledge/` 提取（读 index.md + architecture/） |

## CHECKPOINT

🔴 CHECKPOINT — 展示 Goal + Scope，用户确认后进入 Code Audit
→ [checkpoint-pattern](../../../shared/conventions/checkpoint-pattern.md)
