---
name: workflow-engine
description: >
  project-suite 统一流程引擎。定义 Stage Contract 格式、Validation 框架、QA Sub-Agent 模式。
  所有 project-suite Skill 引用此文件获得统一的流程能力。
  不重复 runtime/engine/ 已有的 state machine / checkpoint / error recovery / confidence gate。
---

# Workflow Engine

> project-suite 统一流程引擎 — Stage Contract + Validation + QA Sub-Agent

## 定位

workflow-engine 不是独立执行的 Skill，而是被所有 project-suite Skill 引用的**流程能力层**。

每个 Skill 通过 `> 遵循 workflow-engine 流程规范` 声明遵循本引擎定义的三个核心能力：

| 能力 | 规范 | 说明 |
|------|------|------|
| Stage Contract | [references/stage-contract.md](references/stage-contract.md) | 每个阶段的 Entry/Input/Actions/Output/Exit/Failure/Recovery 契约 |
| Validation | [references/validation.md](references/validation.md) | 独立验证阶段 + 5 类检查 + validation-report 格式 |
| QA Sub-Agent | [references/qa-pattern.md](references/qa-pattern.md) | Main→QA→Reviewer 三明治 + fresh context 独立审查 |

## 与 runtime/engine/ 的关系

workflow-engine **不重复** runtime/engine/ 已有能力，而是引用它们：

| 能力 | 由谁提供 | 路径 |
|------|---------|------|
| 状态机（idle→discover→...→completed） | runtime/engine | [state-machine.md](../runtime/engine/state-machine.md) |
| 断点续传（manifest.json） | runtime/engine | [checkpoint.md](../runtime/engine/checkpoint.md) |
| 异常恢复（WARNING/DEGRADED/BLOCKED/FATAL） | runtime/engine | [error-recovery.md](../runtime/engine/error-recovery.md) |
| 置信度门禁（PASS/REVIEW/GATE/BLOCK） | runtime/engine | [confidence-gate.md](../runtime/engine/confidence-gate.md) |

workflow-engine 在上层补充 runtime/engine/ 没有覆盖的能力：**阶段结构化契约、独立验证、独立 QA 审查**。

## Skill 如何引用

每个 Skill 的 SKILL.md 顶部加一行：

```markdown
> 遵循 [workflow-engine](../../workflow-engine/SKILL.md) 流程规范
```

工作流部分使用 Stage Contract 格式（参见 [stage-contract.md](references/stage-contract.md)），并包含独立的 Validation 阶段。

## 引用索引

| 资源 | 路径 |
|------|------|
| Stage Contract 规范 | [references/stage-contract.md](references/stage-contract.md) |
| Validation 框架 | [references/validation.md](references/validation.md) |
| QA Sub-Agent 模式 | [references/qa-pattern.md](references/qa-pattern.md) |
| State Machine | [../runtime/engine/state-machine.md](../runtime/engine/state-machine.md) |
| Checkpoint | [../runtime/engine/checkpoint.md](../runtime/engine/checkpoint.md) |
| Error Recovery | [../runtime/engine/error-recovery.md](../runtime/engine/error-recovery.md) |
| Confidence Gate | [../runtime/engine/confidence-gate.md](../runtime/engine/confidence-gate.md) |
