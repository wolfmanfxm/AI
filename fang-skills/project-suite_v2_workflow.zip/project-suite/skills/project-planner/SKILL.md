---
name: project-planner
metadata: skill.yaml
description: >
  Project Planning Engine — 把模糊需求收敛成整个 Suite 都能消费的执行契约（不是 Task Planner）。
  触发词：任务拆解、开发计划、需求分析、排期、估算工作量、分解任务、sprint 规划、
  break down tasks、plan sprint、estimate effort、create dev plan、任务规划。
  产出：PLAN.md — 9 模块 Contract（Goal → Scope → Context → Reuse → Decision → Tasks → Deps → Risk → Acceptance）。
---

# Project Planning Engine

> 模糊需求 → Pipeline 收敛 → 9 模块执行契约 → 全 Suite 可消费
> 遵循 [workflow-engine](../../workflow-engine/SKILL.md) 流程规范 — Stage Contract + Validation + QA

**定位：** 不是 Task Planner。是 Project Planning Engine。职责不是"拆任务"，而是把模糊需求逐步收敛成 Architect、Generator、Reviewer、Tester 都能各自消费的契约。

## 核心原则

1. **Contract over Todo** — 产出 9 模块契约，每个模块标注下游消费者
2. **Knowledge First** — 先扫描 `.project-knowledge/` 可复用资产，再设计
3. **Decision ↔ Task 绑定** — 识别决策点，标注影响哪些 Task，Architect 先 resolve
4. **Confidence 透明** — < 40% 拒绝产出，暴露 Gaps 不强规划

## 职责边界

→ [references/boundary.md](references/boundary.md)

> 🔴 Planning Engine 只产出执行契约。识别决策点但不做架构设计（Architect），拆任务但不写代码（Generator）。

## 前置条件

| 优先级 | 资源 | 缺失时 |
|--------|------|--------|
| 0 | **`context.json`** | 从 `.project-knowledge/` 提取 |
| 1 | `.project-knowledge/` | 跳过 Reuse Analysis，标注"⚠️ 缺少知识库" |
| 2 | 上游 `PLAN.md` / `ARCHITECTURE.md`（若存在） | 标注"⚠️ 无上游规划" |

## 工作流

> Stage Contract 格式 → [workflow-engine](../../workflow-engine/references/stage-contract.md)

### Stage: Discovery

| Contract | Detail |
|----------|--------|
| Entry    | 用户提出规划需求 |
| Input    | context.json (P0), 用户需求描述, 上游 PLAN.md/ARCHITECTURE.md（若存在） |
| Actions  | 1. 加载 context.json → 模块/组件/API 清单 2. 读用户输入 + 上游文档 3. 一句话总结 Goal + 划定 Scope 4. CHECKPOINT — 展示 Goal + Scope |
| Output   | Goal 一句话 + Scope 边界定义 |
| Exit     | 用户确认 Goal + Scope |
| Failure  | 无任何需求输入 → 🔴 BLOCKED; context.json 缺失 → 从 .project-knowledge/ 提取 |
| Recovery | 读 manifest.json → 若 confirmed → 跳过 Goal/Scope 确认 |

🔴 CHECKPOINT — 用户确认后进入现状探查

### Stage: 现状探查（Discovery 后必做）

→ [references/code-audit.md](references/code-audit.md)

| Contract | Detail |
|----------|--------|
| Entry    | Discovery 完成，Goal+Scope 已确认 |
| Input    | 项目源码, PLAN.md Scope 定义 |
| Actions  | 标注 `[新][有骨架][基本完成][已完成]`，修正估时 |
| Output   | 现状标注结果 + 修正后估时 |
| Exit     | 用户确认现状标注 + 修正估时 |
| Failure  | API 文档路径与代码不一致 → 标注 `⤳ 待确认`; 上游 PLAN 过期 → 重新现状探查 |

🔴 CHECKPOINT — 用户确认后进入 Execution

### Stage: Execution — 9 步 Pipeline

| Contract | Detail |
|----------|--------|
| Entry    | 现状探查完成 |
| Input    | context.json, 现状标注结果, 用户需求 |
| Actions  | 9 步 Pipeline → 详见下方表格 |
| Output   | PLAN.md（9 模块完整）+ context-package.json |
| Exit     | 所有 9 个 section 非空，confidence ≥40%（否则仅输出 Goal+Scope+Gap List） |
| Failure  | 需求自相矛盾 → 两方案分别覆盖; 时间不可行 → 最小+完整两版; confidence<40 → 拒绝产出完整 PLAN → [confidence-gate](../../runtime/engine/confidence-gate.md) |
| Recovery | 9 步按序执行，每步完成后标记 manifest.subtask，resume 从第一个 pending 开始 |

| # | 步骤 | 产出 Section | 下游消费者 |
|---|------|-------------|-----------|
| 1 | Goal 定义 | `# Goal` | 全部 Skill |
| 2 | Scope 边界 | `# Scope` | Generator、Reviewer |
| 3 | Context 引用 | `# Context` | Architect、Generator |
| 4 | Reuse Analysis | `# Reuse Analysis` | Generator |
| 5 | Decision 识别 | `# Decision` | Architect |
| 6 | Task Breakdown | `# Task Breakdown` | Generator |
| 7 | Dependency Graph | `# Dependency Graph` | Generator、Runtime |
| 8 | Risk Assessment | `# Risk Assessment` | Reviewer、Tester |
| 9 | Acceptance Criteria | `# Acceptance Criteria` | Tester、Reviewer |

→ 详细 Prompt：[prompts/task-breakdown.md](prompts/task-breakdown.md)
→ 工作量评估：[prompts/estimation.md](prompts/estimation.md)

🔴 CHECKPOINT — 展示 PLAN.md 摘要（任务数+估时+风险TOP3），用户确认后进入 Validation

### Stage: Validation

| # | Check | Method | On Failure |
|---|-------|--------|------------|
| V1 | 9 模块完整 | 每个 section 非空，内容 ≥3 行 | 返回 Execution 补全 |
| V2 | 依赖无循环 | Task Deps 图中无 A→B→A | 🔴 BLOCK — 重新设计 |
| V3 | AC 可验证 | 每条 AC 有明确的 pass/fail 条件 | 标注并降级 confidence |
| V4 | Decision↔Task 绑定 | 每个 Decision 标注影响哪些 Task | 补充映射 |
| V5 | 估时合理 | 单任务 ≤8h，总估时 ≤ 可用工时 | 标注风险 |

**QA Agent**: 全量规划 spawn 独立 agent 用 fresh context 检查逻辑一致性和遗漏 → [qa-pattern](../../workflow-engine/references/qa-pattern.md)
**Output**: validation-report.md
**Exit**: 无 CRITICAL 发现，或所有 CRITICAL 已修复; confidence ≥ 40 才输出完整 PLAN

### Stage: Output

- `.project-knowledge/proposals/PLAN-<feature>.md`（9 模块 Contract）
- **`context-package.json`**（预消化知识包，Generator 直接消费）→ [Context Package](../../runtime/contracts/context-package.schema.json)

## 失败处理

| 触发 | 行为 |
|------|------|
| `.project-knowledge/` 不存在 | 跳过 Reuse Analysis，标注"⚠️ 缺少知识库" |
| 需求自相矛盾 | 标注于 Context 假设表，给出两个方案分别覆盖矛盾分支 |
| 时间不可行 | 给最小可行 + 完整两版，AskUserQuestion |
| Confidence < 40% | **拒绝产出**，只输出 `# Goal` + `# Scope`（含 Gap List） → [confidence-gate](../../runtime/engine/confidence-gate.md) |
| 无任何需求输入 | 🔴 BLOCKED — 拒绝执行 |
| 上游 PLAN.md 存在但代码已大幅变更 | 标注"⚠️ 上游规划可能过期"，重新执行现状探查，diff 后修正 |
| API 文档路径与代码不一致 | 标注为 `⤳ 待确认` 外部依赖，记录在 Dependency Graph |
| 用户中途修改需求范围 | 重新划定 Scope，标记已废弃任务为 `[deprecated]`，AskUserQuestion 确认新范围 |

## 引用索引

| 资源 | 路径 |
|------|------|
| Stage Contract 格式 | [../../workflow-engine/references/stage-contract.md](../../workflow-engine/references/stage-contract.md) |
| Validation 框架 | [../../workflow-engine/references/validation.md](../../workflow-engine/references/validation.md) |
| QA Sub-Agent 模式 | [../../workflow-engine/references/qa-pattern.md](../../workflow-engine/references/qa-pattern.md) |
| 入口 Prompt | [prompts/main.md](prompts/main.md) |
| 任务拆解 | [prompts/task-breakdown.md](prompts/task-breakdown.md) |
| 工作量估算 | [prompts/estimation.md](prompts/estimation.md) |
| 职责边界 | [references/boundary.md](references/boundary.md) |
| 现状探查 | [references/code-audit.md](references/code-audit.md) |
| 失败处理 | [references/failure-handling.md](references/failure-handling.md) |
| 触发词 | [references/trigger-words.md](references/trigger-words.md) |

## 完成后下一步

```
planner 完成 → /project-architect（resolve Decisions）| /project-generator（已全 resolved）
```

## 输出末尾：Workflow Hint 块

→ [references/workflow-hint.md](references/workflow-hint.md)
