---
name: project-reviewer
metadata: skill.yaml
description: >
  对代码变更进行五轴审查：正确性、安全性、可读性、架构、性能。问题分级（BLOCKER/HIGH/MEDIUM/LOW）
  附带精确的 file:line 引用和可操作的修复建议。
  触发词：代码审查、review、检查代码、审查 PR、代码质量、code review、security review、
  audit code、审查、帮我看看这段代码、这个 PR 怎么样。
  产出：REVIEW.md（分级问题列表 + 正向反馈 + 审查结论）。
---

# Reviewer

> 代码变更 + Acceptance Criteria + Risk Assessment → 五轴审查 → 问题分级 → REVIEW.md
> 遵循 [workflow-engine](../../workflow-engine/SKILL.md) 流程规范 — Stage Contract + Validation + QA

## 核心原则

1. **精确引用** — 每个发现标注 `file:line`
2. **AC 对照** — 逐条验证 `PLAN.md > # Acceptance Criteria`
3. **可操作** — 每个问题附带具体修复建议
4. **分级明确** — BLOCKER 必须有明确阻断理由

## 职责边界

→ [references/boundary.md](references/boundary.md)

> 🔴 reviewer 只查不修。发现问题 → 记录 file:line + 修复方案。对照 Scope 检查范围蔓延。

## 反例黑名单

→ [references/boundary.md](references/boundary.md)（6 条，含修复代码/缺file:line/跳过AC/BLOCKER无理由/无PRAISE/跳过项目规范）

## 前置条件

| 优先级 | 资源 | 缺失时 |
|--------|------|--------|
| 0 | **变更 Code**（diff / 文件列表）| 🔴 BLOCKED — 拒绝执行 |
| 1 | **`PLAN.md > # Acceptance Criteria`** | DEGRADED — 标注"⚠️ 无验收标准" |
| 2 | **`PLAN.md > # Risk Assessment`** | DEGRADED — 标准审查强度 |
| 3 | **`PLAN.md > # Scope`** | DEGRADED — 无法检查范围蔓延 |
| 4 | `.project-knowledge/patterns/` | 标注"⚠️ 缺乏项目规范" |
| 5 | `PLAN.md > # Task Breakdown` | 不阻塞 — 判断是否超出规划范围 |
| 6 | `ARCHITECTURE.md` | 不阻塞 — 对照决策检查一致性 |

## 审查轴

| 轴 | 重点 |
|----|------|
| 正确性 | 逻辑错误、边界条件、类型安全、状态一致性、API 契约 |
| 安全性 | 注入、XSS、敏感数据、权限、输入校验 |
| 可读性 | 命名、复杂度、注释、函数长度 |
| 架构 | 模块边界、接口设计、复用、扩展性 |
| 性能 | N+1 查询、渲染、内存、包体积 |

## 问题分级

| 级别 | 判定 |
|------|------|
| 🔴 BLOCKER | 生产事故 → 必须修复 |
| 🟠 HIGH | 大概率引发线上问题 |
| 🟡 MEDIUM | 代码质量可改善 |
| 🟢 LOW | 锦上添花 |
| 🔵 PRAISE | 值得学习 |

## 工作流

> Stage Contract 格式 → [workflow-engine](../../workflow-engine/references/stage-contract.md)

### Stage: Discovery

| Contract | Detail |
|----------|--------|
| Entry    | 用户提交代码审查请求 |
| Input    | 变更 Code (P0 🔴), PLAN.md AC/Risk/Scope (P1), state.json (P2) |
| Actions  | 1. 加载 AC + Risk + Scope 2. 上游 Confidence 检查 → state.json history → generator/tester confidence<70 → 审查强度升至 HIGH 3. Graph 影响分析 → `findImpacted([变更文件])` → `findConsumers(<受影响API>)` → 影响节点>5 → 审查强度升级 4. 按 Risk 定审查强度：HIGH→Full audit / MEDIUM→Spot check / LOW→Standard 5. CHECKPOINT |
| Output   | 审查范围 + 影响节点 + 审查强度 |
| Exit     | 用户确认审查范围 |
| Failure  | 变更文件 >20 → 只审核心文件，其余标注 `⚠️ 未审查`; Graph 不可用 → grep import 手动分析 |

🔴 CHECKPOINT — 确认审查范围+影响节点+审查强度

### Stage: Execution

| Contract | Detail |
|----------|--------|
| Entry    | Discovery 完成，审查范围已确认 |
| Input    | 变更 Code, 审查范围, 审查强度 |
| Actions  | 1. Graph 结构检查：`findConsumers` → 影响模块, `findTransitiveDeps` → 循环依赖检测（命中→🔴 BLOCKER） 2. 五轴扫描 → 每轴逐文件检查 3. AC 逐条验证 → ✅/❌/⚠️ 4. Scope 边界检查 → 超出标注 `[SCOPE CREEP]` 5. Candidate 验证（若 Generator 产出 Candidate）→ 标注 confidence → 满足 R3 (>85) → 更新 knowledge.json 6. CHECKPOINT |
| Output   | 问题列表（按 BLOCKER→LOW 排序）+ PRAISE + AC 对照表 |
| Exit     | 所有文件审查完成，问题已分级 |
| Failure  | 文件过大 → 分段读关键区域; 不熟悉语言 → 仅通用检查，标注 `[超出审查范围]` |
| Recovery | manifest.subtasks 标记每个文件的审查状态 → resume 跳过已审查文件 |

🔴 CHECKPOINT — 展示审查摘要（BLOCKER/HIGH/MEDIUM/LOW/PRAISE 计数）

### Stage: Validation

> reviewer 的 Validation 是元审查 — 检查审查本身的质量

| # | Check | Method | On Failure |
|---|-------|--------|------------|
| V1 | 五轴全覆盖 | 每轴至少 1 条记录（含 PRAISE 或 PASS 标注） | 补全未覆盖轴 |
| V2 | file:line 有效 | 每个发现的路径+行号对应文件存在 | 修正引用 |
| V3 | AC 逐条对照 | AC 表逐条 ✅/❌/⚠️，无遗漏 | 补全遗漏 AC |
| V4 | 分级合理 | BLOCKER 有明确阻断理由，无 LOW 误标 BLOCKER | 调整分级 |
| V5 | Scope 边界检查 | 标注超出 PLAN.md Scope 的变更 | 补充 `[SCOPE CREEP]` |

**QA Agent**: BLOCKER>0 或变更文件>10 → spawn 独立 agent 验证 BLOCKER 的真实性和修复建议的可操作性 → [qa-pattern](../../workflow-engine/references/qa-pattern.md)
**Output**: REVIEW.md（含 validation notes）
**Exit**: 无 CRITICAL 发现（BLOCKER 判定无误、分级合理）

### Stage: Output

`.project-knowledge/reports/REVIEW-<topic>.md`：问题列表（按 BLOCKER→HIGH→MEDIUM→LOW 排序）+ PRAISE + AC 对照表 + 审查结论

## 失败处理

| 触发条件 | 一线修复 | 仍失败兜底 |
|---------|---------|-----------|
| 变更文件 > 20 | 只审查核心文件（按变更量+风险排序），其余标注 `⚠️ 未审查` | AskUserQuestion：全审 / 核心 / 指定文件 |
| 文件过大无法完整读取 | 分段读关键区域（函数签名+分支+异常处理），标注 `⚠️ 未完整审查` | 限审查深度，优先发现 BLOCKER |
| `.project-knowledge/` 不存在 | 使用通用代码质量标准审查，标注 `⚠️ 缺乏项目规范` | 不阻塞 — 通用标准仍有效 |
| 不熟悉的语言/框架 | 仅做通用检查（命名/结构/注释），标注 `[超出审查范围]` | 跳过语言特有检查，不强制推断 |
| PLAN.md 缺失无法对照 AC | 从代码推断功能意图，标注 `⚠️ 无验收标准` | 不阻塞 — 降级为纯代码审查 |
| Graph 不可用（graph.json 缺失） | 手动分析 import 依赖链（grep import），标注 `⚠️ 无 Graph` | 影响范围分析降级为静态 import 扫描 |

## 引用索引

| 资源 | 路径 |
|------|------|
| Stage Contract 格式 | [../../workflow-engine/references/stage-contract.md](../../workflow-engine/references/stage-contract.md) |
| Validation 框架 | [../../workflow-engine/references/validation.md](../../workflow-engine/references/validation.md) |
| QA Sub-Agent 模式 | [../../workflow-engine/references/qa-pattern.md](../../workflow-engine/references/qa-pattern.md) |
| 入口 Prompt | [prompts/main.md](prompts/main.md) |
| 正确性审查 | [prompts/correctness.md](prompts/correctness.md) |
| 安全性审查 | [prompts/security.md](prompts/security.md) |
| 职责边界 | [references/boundary.md](references/boundary.md) |
| 严重度分级 | [references/severity-guide.md](references/severity-guide.md) |
| 失败处理 | [references/failure-handling.md](references/failure-handling.md) |

## 完成后下一步

```
reviewer 完成 → /project-generator(修复) 或 /project-documenter 或 /project-releaser
```
