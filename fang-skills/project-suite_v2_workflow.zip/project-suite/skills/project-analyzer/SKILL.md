---
name: project-analyzer
metadata: skill.yaml
description: >
  分析软件项目并生成可复用的项目知识库，覆盖架构、组件、API、模式、编码风格等维度。
  触发词：分析项目、代码分析、项目审计、扫描项目、梳理组件、更新项目知识、刷新项目知识、
  项目规范、编码规范、analyze codebase、scan project、project refresh。
  产出：.project-knowledge/ + Knowledge Vault。仅写知识文件，不修改源码。
---

# Analyzer

> 代码扫描 → 7 维度分析 → 结构化知识库 → Vault 同步
> 遵循 [workflow-engine](../../workflow-engine/SKILL.md) 流程规范 — Stage Contract + Validation + QA

## 职责边界

→ [references/boundary.md](references/boundary.md)

## 前置条件

| 优先级 | 资源 | 缺失时 |
|--------|------|--------|
| 0 | **项目源码**（工作目录）| 🔴 BLOCKED |
| 1 | Knowledge Vault 路径 | 🟡 DEGRADED — 跳过 Vault 同步 |

## Quick Start

```
"分析/扫描/刷新"              → Analysis Flow
manifest status = completed    → 询问: 🔁全量 / 📝增量 / ❌取消
```

## 工作流

> Stage Contract 格式 → [workflow-engine](../../workflow-engine/references/stage-contract.md)

### Stage: Discovery

| Contract | Detail |
|----------|--------|
| Entry    | 用户触发分析需求 |
| Input    | Project Root（工作目录） |
| Actions  | 1. 探测技术栈、目录结构、Vault 路径（`$HOME/Data/Knowledge Vault` → `./Knowledge Vault` → `$HOME/Documents/Knowledge Vault`） 2. AskUserQuestion 确认：项目名/深度/范围/输出位置 3. 写入 analysis-config.json + manifest.json |
| Output   | analysis-config.json（含 vaultPath）, manifest.json (status=discover) |
| Exit     | framework identified, package manager identified, scope confirmed, config written |
| Failure  | 无 package.json → AskUserQuestion 手动指定; 权限不足 → 🔴 BLOCKED |
| Recovery | 读 manifest.json → 若 config 已存在 → 跳过探测，直入 CHECKPOINT |

🔴 CHECKPOINT → [checkpoint 模式](../../shared/conventions/checkpoint-pattern.md)

### Stage: Execution

| Contract | Detail |
|----------|--------|
| Entry    | Discovery 完成，scope 已确认 |
| Input    | analysis-config.json, 项目源码 |
| Actions  | 按 scope、mode 并行 spawn agent（7 维度 + 变更分析） |
| Output   | 各维度 .md 文件（≥100 bytes），manifest.subtasks 全部 completed/failed |
| Exit     | 所有维度返回结果（completed 或 gracefully failed），文件已验证存在 |
| Failure  | agent 超时 → retry once，仍失败标注 `❌ FAILED`; agent 返回空 → 主流程补写 → [error-recovery](../../runtime/engine/error-recovery.md) |
| Recovery | manifest.subtasks 标记 completed/failed → resume 只执行 pending → [checkpoint](../../runtime/engine/checkpoint.md) |

**维度表：** 反例 → [references/anti-patterns.md](references/anti-patterns.md)

| 维度 | 指南 | 输出 |
|------|------|------|
| 架构 | [prompts/architecture.md](prompts/architecture.md) | `overview.md` + `modules.md` `tech-stack.md` |
| 组件 | [prompts/components.md](prompts/components.md) | `catalog.md` |
| 编码 | [prompts/coding-style.md](prompts/coding-style.md) | `vue.md` `typescript.md` `naming.md` |
| UI | [prompts/ui-pattern.md](prompts/ui-pattern.md) | `table.md` `form.md` `dialog.md` |
| API | [prompts/api-pattern.md](prompts/api-pattern.md) | `overview.md` `request.md` |
| 模式 | [prompts/patterns.md](prompts/patterns.md) | `crud.md` 等 |
| 观察 | [prompts/observations.md](prompts/observations.md) | `statistics.md` |
| 变更 | [prompts/change-analysis.md](prompts/change-analysis.md) | `change-log.md`（详尽必选） |

**Agent 协调规则：** 禁止提前返回 → 全部完成后一次性写入 → 写入失败重试一次 → 仍失败标注 `❌ FAILED: [原因]` → 写入后 `ls -la` 验证每个文件 ≥100 bytes。每维度 agent prompt 按 4 部分组装：任务描述 + 项目上下文 + 产出要求 + 失败处理 → [prompts/output-format.md](prompts/output-format.md)

### Stage: Delivery

> 原 Finish 4-Phase，详见 [references/finish-workflow.md](references/finish-workflow.md)

| Contract | Detail |
|----------|--------|
| Entry    | Execution 完成，所有维度文件已写入 |
| Input    | 各维度 .md 文件, manifest.json, analysis-config.json |
| Actions  | Phase A 强制刷新（statistics/context/graph/search-index 禁止复用缓存）→ Phase B 状态初始化（.project-runtime/ state + knowledge）→ Phase C 差异化更新（仅 `[CHANGED]` 维度写 .md）→ Phase D 质量验证（knowledge-health + CLAUDE.md + Vault sync + timeline） |
| Output   | statistics.json, context.json, graph.json, search-index.json, knowledge.json, CLAUDE.md 更新, timeline 追加 |
| Exit     | manifest status = completed, Vault sync 验证通过（文件差 ≤3） |
| Failure  | graph.json 生成失败 → grep 回退; Vault 不可达 → 跳过并标注; CLAUDE.md 不存在 → 从 package.json+tsconfig 推断 |
| Recovery | manifest 完整性校验后才置 completed; Phase A JSON 禁止复用缓存数字 |

### Stage: Validation

> 验证框架 → [workflow-engine](../../workflow-engine/references/validation.md)

| # | Check | Method | On Failure |
|---|-------|--------|------------|
| V1 | 架构完整性 | overview/modules/tech-stack 均非空 | 返回 Execution 补全 |
| V2 | API 引用有效性 | 文档引用的源文件路径存在（`ls` 验证） | 标注 `[BROKEN REF]` |
| V3 | 组件存在性 | catalog.md 中组件路径可访问 | 标注 `[MISSING]` |
| V4 | 内部链接可达 | 所有 .md `[text](path)` 目标文件存在 | 标注 `[DEAD LINK]` |
| V5 | 无空白章节 | 无连续 >3 行空段落 | 标注 `[EMPTY]` |
| V6 | 无重复内容 | 跨文件无 >80% 相似段落 | 标注 `[DUPLICATE]` |
| V7 | 统计一致性 | statistics.json 数字与 .md 文件数一致 | 重新计数更新 |

**QA Agent**: 全量模式 spawn 独立 agent，仅读产出文件（不含对话上下文），检查遗漏和矛盾 → [qa-pattern](../../workflow-engine/references/qa-pattern.md)
**Output**: validation-report.md
**Exit**: 无 CRITICAL 发现，或所有 CRITICAL 已修复并记录到 manifest

## 失败处理

| 触发条件 | 一线修复 | 仍失败兜底 |
|---------|---------|-----------|
| 子 agent 超时或返回空 | 重试一次（同 agent 同 prompt） | 标注 `❌ FAILED: [维度名]`，主流程补写 |
| 写入文件失败（权限/磁盘满） | 重试一次 | 标注 `❌ FAILED`，不阻塞其他维度 |
| `.claude/CLAUDE.md` 不存在 | 直接生成 `.project-knowledge/`，Vault 同步照常 | 标注 `⚠️ 无 CLAUDE.md`，从 package.json+tsconfig 推断 |
| Knowledge Vault 路径不可达 | 跳过 Vault 同步 | 标注 `⚠️ Vault 不可达`，`.project-knowledge/` 仍写入 |
| graph.json 生成失败 | grep + 纯文本解析回退 | 标注 `⚠️ graph.json 未生成`，不影响其他产出 |

## 引用索引

| 资源 | 路径 |
|------|------|
| Stage Contract 格式 | [../../workflow-engine/references/stage-contract.md](../../workflow-engine/references/stage-contract.md) |
| Validation 框架 | [../../workflow-engine/references/validation.md](../../workflow-engine/references/validation.md) |
| QA Sub-Agent 模式 | [../../workflow-engine/references/qa-pattern.md](../../workflow-engine/references/qa-pattern.md) |
| Finish 详细步骤 | [references/finish-workflow.md](references/finish-workflow.md) |
| 产出格式规范 | [prompts/output-format.md](prompts/output-format.md) |
| 维度 Prompt | [prompts/](prompts/) |
| 职责边界+反例 | [references/boundary.md](references/boundary.md) |
| 失败处理 | [references/failure-handling.md](references/failure-handling.md) |
| State Machine | [../../runtime/engine/state-machine.md](../../runtime/engine/state-machine.md) |
| Checkpoint | [../../runtime/engine/checkpoint.md](../../runtime/engine/checkpoint.md) |
| Error Recovery | [../../runtime/engine/error-recovery.md](../../runtime/engine/error-recovery.md) |
| Confidence Gate | [../../runtime/engine/confidence-gate.md](../../runtime/engine/confidence-gate.md) |

## 完成后下一步

```
analyzer 完成 → /project-planner 或 /project-architect 或 ✅
```
