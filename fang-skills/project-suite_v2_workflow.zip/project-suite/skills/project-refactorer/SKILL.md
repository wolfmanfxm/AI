---
name: project-refactorer
metadata: skill.yaml
description: >
  改善代码结构不改变外部行为：提取函数/组件、简化条件逻辑、移除死代码、语义化重命名、
  拆分过大模块。每次重构必须安全可逆，有测试跑测试，无测试先加表征测试。
  触发词：重构、优化结构、提取公共、简化代码、消除重复、拆分模块、重命名、
  refactor、clean up、extract method、simplify、reduce complexity、优化这段代码。
  产出：重构后代码 + REFACTOR.md（变更记录 + 改善指标 + 验证结果）。
---

# Refactorer

> 代码 → 识别坏味道 → 安全重构 → 验证 → REFACTOR.md
> 遵循 [workflow-engine](../../workflow-engine/SKILL.md) 流程规范 — Stage Contract + Validation + QA

## 核心原则

1. **行为不变** — 重构前后外部行为完全一致
2. **安全第一** — 有测试先跑测试，没测试先加表征测试
3. **小步快跑** — 每次只做一个重构动作，可独立提交回滚
4. **可量化** — "圈复杂度 15→3" > "改好了"

## 职责边界

→ [references/boundary.md](references/boundary.md)

> 🔴 refactorer 只改善结构不改行为。没测试保护不重构。

## 反例黑名单

| # | ❌ 反模式 | 为什么不要做 | ✅ 正确做法 |
|---|---------|-------------|-----------|
| 1 | **无测试保护直接重构** | 重构后行为变化无人知晓，引入回归bug | 有测试先跑绿 → 无测试先加表征测试 → 确认绿后才重构 |
| 2 | **一次性重构 >5 个文件** | 变更范围大难以 review，一旦出错回滚成本高 | 拆分为多次小重构，每次 1-2 文件，独立提交 |
| 3 | **重构同时改功能** | 行为和结构同时变化，diff 无法区分哪个导致问题 | 重构 commit 只做结构变化，功能变更单独 commit |
| 4 | **不量化改善效果** | "感觉好多了"无法说服 review，下次重构无基线对比 | REFACTOR.md 记录：圈复杂度 15→3 / 行数 800→320 / 重复率 40%→5% |
| 5 | **测试变红后强行提交** | 重构引入了 bug 但被忽略，后续开发者基于坏代码继续工作 | 测试变红 → `git diff` 逐段排查 → 无法定位则 `git revert` 整个重构 |

## 前置条件

| 优先级 | 资源 | 缺失时 |
|--------|------|--------|
| 0 | **待重构代码** | 🔴 BLOCKED |
| 1 | 现有测试 | 🟡 DEGRADED — 无测试保护不重构 |
| 2 | `.project-knowledge/patterns/` | 🟡 DEGRADED |

## 工作流

> Stage Contract 格式 → [workflow-engine](../../workflow-engine/references/stage-contract.md)

### Stage: Discovery

| Contract | Detail |
|----------|--------|
| Entry    | 用户提出重构需求 |
| Input    | 待重构代码 (P0 🔴), 现有测试 (P1) |
| Actions  | 1. 识别坏味道：长函数/重复代码/过深嵌套/God Class/魔数 2. 确认测试覆盖：有测试→跑一遍；无测试→加表征测试 3. 选重构手法（9种）→ [prompts/extract-method.md](prompts/extract-method.md) 4. CHECKPOINT |
| Output   | 坏味道清单 + 重构策略 + 测试状态 |
| Exit     | 用户确认重构范围 |
| Failure  | 无测试覆盖 → 先写表征测试; 现有测试失败 → 停止，建议先修测试 |

🔴 CHECKPOINT → [checkpoint 模式](../../shared/conventions/checkpoint-pattern.md)

### Stage: Execution（小步循环）

| Contract | Detail |
|----------|--------|
| Entry    | Discovery 完成，测试全绿 |
| Input    | 待重构代码, 测试文件, 重构策略 |
| Actions  | 循环：1. 跑现有测试 → 确认全绿 2. 做 1 个重构动作 3. 跑测试 → 仍绿 → commit 4. 变红 → revert → 分析记录 → 继续下一个动作 |
| Output   | 重构后代码（每步独立 commit） |
| Exit     | 目标达成，所有测试保持绿色 |
| Failure  | 测试变红 → `git diff` → 逐段回滚; 范围过大(>5文件) → 拆分; 改善不明显(<20%) → 标注"⚠️ 边际改善" |
| Recovery | git reflog 可定位每步重构 commit → resume 从最后一个成功 commit 继续 |

🔴 CHECKPOINT — 展示重构摘要（改动文件数 + Before→After 指标 + 测试结果）

### Stage: Validation

| # | Check | Method | On Failure |
|---|-------|--------|------------|
| V1 | 行为不变 | 重构前后测试结果一致（全绿→全绿） | 🔴 BLOCK — git revert |
| V2 | 指标改善 | 圈复杂度/行数/重复率 至少一项改善 >10% | 标注"⚠️ 边际改善" |
| V3 | 范围受控 | 改动文件 ≤5，每个 commit 一个动作 | 拆分过大的重构 |
| V4 | 测试保护 | 每次重构前测试全绿，重构后仍全绿 | 停止重构，先修测试 |
| V5 | Commit 原子性 | 每个 commit 只做一件事，message 描述具体动作 | 拆分混合 commit |

**QA Agent**: 改动文件 >3 → spawn 独立 agent 验证重构安全性（行为不变、无新增 regression）→ [qa-pattern](../../workflow-engine/references/qa-pattern.md)
**Output**: REFACTOR.md（变更清单 + Before→After 指标 + 测试结果 + QA findings）
**Exit**: 无 CRITICAL 发现

### Stage: Output

`.project-knowledge/reports/REFACTOR.md`：
- 变更清单（每个重构动作 + commit hash）
- 改善指标（圈复杂度/行数/重复率/依赖深度，Before→After）
- 测试结果（通过数/失败数/跳过数）
- 失败记录（若有 revert，记录原因+教训）

## 失败处理

| 触发条件 | 一线修复 | 仍失败兜底 |
|---------|---------|-----------|
| 无测试覆盖（项目无测试框架） | 先写表征测试（characterization test）— 记录当前行为 | 标注"⚠️ 无测试保护"，缩小重构范围到纯提取/重命名 |
| 现有测试失败（重构前就不绿） | 停止重构，记录失败测试到 REFACTOR.md | 建议先 `/project-tester` 修复，不强行重构 |
| 重构后测试变红 | `git diff` 对比变更，逐段回滚到最近一个绿点 | `git revert` 整个重构 commit，REFACTOR.md 记录失败原因 |
| 重构范围过大（>5 文件） | 拆分为多次小重构，每次 1-2 文件 | AskUserQuestion 确认是否一次性重构 |
| 圈复杂度改善不明显（<20%） | 尝试更激进的手法（提取策略模式、引入多态） | 标注"⚠️ 边际改善"，不强制继续 |

## 引用索引

| 资源 | 路径 |
|------|------|
| Stage Contract 格式 | [../../workflow-engine/references/stage-contract.md](../../workflow-engine/references/stage-contract.md) |
| Validation 框架 | [../../workflow-engine/references/validation.md](../../workflow-engine/references/validation.md) |
| QA Sub-Agent 模式 | [../../workflow-engine/references/qa-pattern.md](../../workflow-engine/references/qa-pattern.md) |
| 入口 Prompt | [prompts/main.md](prompts/main.md) |
| 提取方法 | [prompts/extract-method.md](prompts/extract-method.md) |
| 简化逻辑 | [prompts/simplify-logic.md](prompts/simplify-logic.md) |
| 职责边界 | [references/boundary.md](references/boundary.md) |
| 安全协议 | [references/safety-protocol.md](references/safety-protocol.md) |
| 失败处理 | [references/failure-handling.md](references/failure-handling.md) |

## 完成后下一步

```
refactorer 完成 → /project-tester 或 /project-reviewer
```
