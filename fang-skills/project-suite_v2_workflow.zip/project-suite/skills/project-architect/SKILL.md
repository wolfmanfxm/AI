---
name: project-architect
metadata: skill.yaml
description: >
  架构决策、技术选型、模块设计、API 契约设计。使用对比矩阵做技术选型，输出 ADR 格式的架构决策记录。
  触发词：架构设计、技术选型、模块设计、系统设计、数据库设计、API 设计、架构评审、
  怎么设计、选什么技术、模块怎么划分、接口怎么定义、design architecture、tech stack、
  system design、API design。
  产出：ARCHITECTURE.md（ADR 决策记录 + 模块图 + 选型理由 + API 契约）。
---

# Architect

> 需求 → 技术选型 → 模块设计 → API 契约 → ARCHITECTURE.md
> 遵循 [workflow-engine](../../workflow-engine/SKILL.md) 流程规范 — Stage Contract + Validation + QA

## 核心原则

1. **决策可追溯** — 问题 → 候选方案 → 选择 → 理由
2. **上下文驱动** — 选型基于项目约束，不追求银弹
3. **够用就好** — 当前需求 + 可预见扩展
4. **基于事实** — 有 `.project-knowledge/` 时基于现有架构

## 职责边界

→ [references/boundary.md](references/boundary.md)

> 🔴 architect 只做设计不写代码。

## 反例黑名单

→ [references/boundary.md](references/boundary.md)

## 前置条件

| 优先级 | 资源 | 缺失时 |
|--------|------|--------|
| 0 | **`context.json`** | 从 `.project-knowledge/architecture/` 提取 |
| 1 | `.project-knowledge/architecture/` | 标注"未分析" |
| 2 | `PLAN.md`，**若存在必读** | 标注"⚠️ 无规划" |
| 3 | 上游源码，**现状核实必读** | 标注"⚠️ 未核实" |

## 工作流

> Stage Contract 格式 → [workflow-engine](../../workflow-engine/references/stage-contract.md)

### Stage: Discovery

| Contract | Detail |
|----------|--------|
| Entry    | 用户提出架构/设计需求 |
| Input    | context.json (P0), PLAN.md (P1), 用户设计需求 |
| Actions  | 1. 确认设计范围 + 收集约束 2. CHECKPOINT — 展示设计范围 + 约束清单 |
| Output   | 设计范围 + 约束清单 |
| Exit     | 用户确认设计范围 |
| Failure  | 设计范围完全未指定 → 🔴 BLOCKED，提示先 /project-planner |
| Recovery | manifest.json → 若 confirmed → 跳过范围确认 |

🔴 CHECKPOINT

### Stage: 现状核实（Discovery 后必做）

→ [references/code-audit.md](references/code-audit.md)

| Contract | Detail |
|----------|--------|
| Entry    | 设计范围已确认 |
| Input    | 项目源码, 设计范围 |
| Actions  | 标注 `[已实现][部分实现][未实现]` |
| Output   | 现状核实结果（已实现的不再出设计方案） |
| Exit     | 核实完成，范围已修正 |
| Failure  | 源码不可读 → 标注"⚠️ 未核实"，按未实现出方案 |

### Stage: Graph 分析

→ [Graph Query Protocol](../../runtime/contracts/graph-query.md)

| Contract | Detail |
|----------|--------|
| Entry    | 现状核实完成 |
| Input    | graph.json |
| Actions  | 1. `findDependencies(<目标模块>)` → 模块耦合度 2. 全图 edges 按 group 聚合 → 识别跨层依赖 3. `findConsumers(<目标API>)` → 修改影响范围 4. 循环依赖检测 → 标注架构风险 |
| Output   | Graph 分析结果（耦合度/跨层依赖/影响范围/循环依赖） |
| Exit     | 用户确认分析结果，范围已调整 |

🔴 CHECKPOINT

### Stage: Execution

| Contract | Detail |
|----------|--------|
| Entry    | Graph 分析完成，范围已确认 |
| Input    | context.json, PLAN.md, 现状核实结果, Graph 分析结果 |
| Actions  | 按用户意图路由：技术选型 → [prompts/tech-selection.md](prompts/tech-selection.md)；模块设计 → [prompts/module-design.md](prompts/module-design.md)；API 契约 → [prompts/api-design.md](prompts/api-design.md)；综合 → 1→2→3 顺序，每步 CHECKPOINT |
| Output   | ARCHITECTURE.md（ADR 决策记录 + 模块图 + API 契约） |
| Exit     | 所有设计决策已记录，无未 resolve 的 trade-off |
| Failure  | 对比矩阵分差 <10% → 展示对比+权衡分析，AskUserQuestion 选择 |

🔴 CHECKPOINT — 展示 ARCHITECTURE.md 摘要

### Stage: Validation

| # | Check | Method | On Failure |
|---|-------|--------|------------|
| V1 | ADR 决策链完整 | 问题→候选方案→选择→理由 四段不缺 | 返回 Execution 补全 |
| V2 | 对比矩阵完整 | 候选方案 ≥2，维度 ≥3，分差说明 | 补全矩阵 |
| V3 | 现状核实准确 | `[已实现]` 标注的模块路径存在 | 修正标注 |
| V4 | API 契约可实施 | 每个 endpoint 有 method/path/request/response | 补全缺失字段 |
| V5 | 模块耦合合理 | 跨层依赖（view→infrastructure）已标注原因 | 标注架构风险 |

**QA Agent**: 综合设计 → spawn 独立 agent 检查方案自洽性和遗漏 → [qa-pattern](../../workflow-engine/references/qa-pattern.md)
**Output**: validation-report.md
**Exit**: 无 CRITICAL 发现

### Stage: Output

`.project-knowledge/decisions/ARCHITECTURE-<topic>.md`

## 失败处理

| 触发条件 | 一线修复 | 仍失败兜底 |
|---------|---------|-----------|
| `.project-knowledge/architecture/` 不存在 | 从代码结构推断模块边界 | 标注"⚠️ 未分析现有架构"，通用模式设计 |
| PLAN.md `# Decision` 为空（无待 resolve 决策） | 自行识别架构决策点 | 标注"⚠️ 自行识别决策点" |
| 候选方案无明确最优（对比矩阵分差 < 10%） | 展示对比 + 权衡分析，标注推荐 | AskUserQuestion 让用户选择 |
| 现状核实源码不可读 | 标注"⚠️ 未核实"，按未实现出方案 | 不基于猜测做架构决策 |
| 设计范围完全未指定 | 🔴 BLOCKED — 拒绝执行 | 提示用户先执行 `/project-planner` |

→ 详细: [references/failure-handling.md](references/failure-handling.md)

## 引用索引

| 资源 | 路径 |
|------|------|
| Stage Contract 格式 | [../../workflow-engine/references/stage-contract.md](../../workflow-engine/references/stage-contract.md) |
| Validation 框架 | [../../workflow-engine/references/validation.md](../../workflow-engine/references/validation.md) |
| QA Sub-Agent 模式 | [../../workflow-engine/references/qa-pattern.md](../../workflow-engine/references/qa-pattern.md) |
| 入口 Prompt | [prompts/main.md](prompts/main.md) |
| 技术选型 | [prompts/tech-selection.md](prompts/tech-selection.md) |
| 模块设计 | [prompts/module-design.md](prompts/module-design.md) |
| API 契约 | [prompts/api-design.md](prompts/api-design.md) |
| 职责边界 | [references/boundary.md](references/boundary.md) |
| 决策框架 | [references/decision-framework.md](references/decision-framework.md) |
| 现状核实 | [references/code-audit.md](references/code-audit.md) |
| 失败处理 | [references/failure-handling.md](references/failure-handling.md) |

## 完成后下一步 → /project-generator 或 /project-reviewer

## 输出末尾：Workflow Hint 块

→ [references/workflow-hint.md](references/workflow-hint.md)
