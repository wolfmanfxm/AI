# Knowledge Compiler v1.0.0

> 汇总、分类、索引知识。**不是 analyzer**——analyzer 从代码发现知识（→ `graph.json`）。
> Compiler 扫描 **authored knowledge**（`.project-knowledge/` 下的 .md 文件），打上统一元数据，生成 `knowledge-index.json`。
> `graph.json`（JSON 代码事实）是 **Resolver 的结构事实输入**，不是 Compiler 输入。

## 职责边界

| 模块 | 职责 | 产物 |
|------|------|------|
| project-analyzer | 从代码发现知识 | `graph.json`（代码事实/结构，Resolver 输入） |
| **knowledge-compiler** | 扫描 .md 知识 → 分类/打标签 | `knowledge-index.json`（metadata-only） |
| context-resolver | 按任务分桶 + hydrate | `context-package.json` |

关键区分：

- `graph.json` = analyzer 的「代码事实」，是 **Resolver 的结构事实输入，不是 Compiler 输入**。
- `rules/decisions/experience/playbooks` = 用户手工维护的**强制约束**，Compiler 必须扫进来。
- `knowledge-index.json` = 统一索引，**只存 metadata，不复制 Markdown 正文**。

## 输入（.md 知识源）

Compiler 扫描 `.project-knowledge/` 下 8 个目录的 .md 文件（**不含 `graph.json`**）：

| 目录 | 来源 | 级别 |
|------|------|------|
| `rules/` `decisions/` | 用户手写强制约束 | P1 |
| `patterns/` `components/` `api/` `architecture/` | analyzer 产出参考模式 | P2 |
| `experience/` `playbooks/` | 用户手写经验/手册 | P3 |

> `graph.json`（analyzer 的 JSON 代码事实）**不是 Compiler 输入**，是 Resolver 的结构事实输入（findNode/findTransitiveDeps）。

## 输出

`.project-knowledge/knowledge-index.json`（capability-keyed + 每文件 Knowledge Metadata）

## 元数据映射（默认，可被文件 frontmatter 覆盖）

| 目录 | type | enforcement | priority |
|------|------|-------------|----------|
| `rules/` | rule | blocking | P1 |
| `decisions/` | decision | 按 scope：project→blocking/P1，task→advisory/P2 | 见下方 decision 区分 |
| `patterns/` `components/` `api/` `architecture/` | pattern / component / api | recommended | P2 |
| `experience/` `playbooks/` | experience / playbook | advisory / recommended | P3 |

> 分类规则：先看 `type`（是什么类别）→ 定 `priority`（P1/P2/P3）→ 定 `enforcement`（blocking/recommended/advisory）。

## constraint 必需性（按 type 分级）

| type | constraint | 说明 |
|------|-----------|------|
| `rule`（`rules/`） | **REQUIRED** | 强制编码规则必须有精确的一句话约束 |
| `decision`（`decisions/`，长期 project decision） | **REQUIRED** | 长期项目决策必须写清约束 |
| `experience` / `playbook` | OPTIONAL | 经验/手册无强制约束 |
| `pattern` / `component` / `api` | 不需要 | 走 `context-package` 的 `knowledge.constraints` |

> **decision 区分（已实现）**：compiler 用 `detect_scope` 确定性区分——优先 frontmatter `scope:`，
> 否则按文件名约定（`ARCHITECTURE-*.md` → task，其余 → project）。
> project decision → enforcement=blocking（进 constraints，constraint REQUIRED）；
> task decision（一次性 feature ADR）→ enforcement=advisory（进 guidance，不进 blocking）。

## 触发时机（change-detection）

1. **每次任务开始前**：检查 `.project-knowledge/` 下 8 个目录的 .md 是否有变化：
   - 有变化 → 重扫 .md（不重跑 analyzer）
   - 无变化 → 直接复用已有 index

> 用户改一条 rule 后，**不需要重跑 analyzer，也不需要跑 documenter**。Compiler 检测到 `rules/` 变化 → 重扫 → 更新 index。
> `graph.json` 变化**不触发** Compiler（它是 Resolver 输入，每次任务由 Resolver 直接读取）。

## 与 analyzer / resolver 的关系

```
project-analyzer ──→ graph.json ──────────────────────────┐
                                                          ↓
knowledge-compiler ──→ knowledge-index.json ──→ context-resolver ──→ context-package.json
      ↑                                             ↑
rules/decisions/experience/playbooks/patterns/...   graph.json（结构事实，Resolver 直接读）
```

- Compiler 只扫 .md 知识文件，**不碰 graph.json**。
- graph.json 是 Resolver 的输入（findNode/findTransitiveDeps 选相关 knowledge）。
- Compiler 独立于 analyzer：改 rule 只重扫 .md，不重跑 analyzer。

## 自校验

Compiler 完成后校验（失败则 exit 1，拒绝生成有效 index）：

- `source` 存在
- `type` / `enforcement` / `priority` 取值合法
- `rules` / `decisions` 都含 `constraint`（REQUIRED）
- 无重复 source
- 无悬空 capability

> 校验结果不单独落文件，直接以 exit code 表达：`exit 0` = 有效，`exit 1` = 无效（打印 ❌ 清单）。
